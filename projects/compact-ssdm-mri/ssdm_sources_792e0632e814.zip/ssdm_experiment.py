"""Full-resolution SSDM experiment orchestration.

Paper constants: 320x320, L=8, LISTA=12, R=8/16, ACS=4%, two100epoch stages,
100 inference steps. Optimizer/LR/batch/loss weights are disclosed choices.
No image resizing, subset selection, or shortened training occurs implicitly.
"""
from dataclasses import dataclass, asdict
from pathlib import Path
import contextlib
import hashlib
import json
import os
import random
import shutil
import time
import tarfile
import urllib.request
import zipfile
import numpy as np
import h5py
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
from ssdm_cdl import CoupledDictionary, CDLLossWeights, coupled_dictionary_loss
from ssdm_cdl import complex_to_ri, ri_to_complex, fft2c, ifft2c
from ssdm_backbone import SSDMUNet, BackboneConfig
from ssdm_sampling import sample_ssdm, SamplerConfig


@dataclass
class ExperimentConfig:
    train_dir: str = "/content/ssdm_cache/train"
    val_dir: str = "/content/ssdm_cache/val"
    output_dir: str = "/content/ssdm_paper_run"
    image_size: int = 320
    cdl_epochs: int = 100
    diffusion_epochs: int = 100
    evaluation_subjects: int = 199
    center_fraction: float = .04
    accelerations: tuple = (8, 16)
    batch_images: int = 1
    cdl_lr: float = 1e-4
    diffusion_lr: float = 1e-4
    reconstruction_weight: float = 1e-3
    timesteps: int = 1000
    beta_start: float = 1e-4
    beta_end: float = .02
    precision: str = "fp16"
    activation_cpu_offload: bool = True
    seed: int = 42
    checkpoint_every: int = 100
    require_completed_archives: bool = True
    session_seconds: int = 6 * 3600


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def json_write(path, content):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(content, indent=2, ensure_ascii=False), encoding="utf8")
    os.replace(tmp, path)


def readable_h5(path, full=True):
    try:
        with h5py.File(path, "r") as f:
            if "images_complex64" in f:
                from ssdm_cache import validate_cache
                return validate_cache(path, full=full)
            k = f["kspace"]
            if k.ndim != 3 or "reconstruction_esc" not in f:
                return False
            for i in (0, k.shape[0] // 2, k.shape[0] - 1):
                if not np.isfinite(k[i]).all():
                    return False
        return True
    except (OSError, KeyError):
        return False


def prepare_archive(url, directory, max_new_files=None, reserve_gb=12):
    """Stream the NYU tar.xz once, without retaining compressed archives.

    max_new_files=None is the entire split. A bounded download is explicitly
    marked incomplete and is suitable only for implementation verification.
    Personal signed URLs are never written to a manifest/checkpoint/log.
    """
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    report = directory / "download_manifest.json"
    if report.exists() and max_new_files is None:
        old = json.loads(report.read_text())
        files = old.get("archive_files", [])
        if old.get("complete_archive") and files and all((directory / n).exists() for n in files):
            print("Complete archive already present:", directory, len(files), flush=True)
            return old
    if not url.startswith("https://fastmri-dataset.s3.amazonaws.com/"):
        raise ValueError("Supply the NYU fastMRI download URL for this split")
    count = 0
    names = []
    complete = True
    print("Streaming", directory.name, "(the URL is kept private)", flush=True)
    try:
        with urllib.request.urlopen(url, timeout=120) as response:
            with tarfile.open(fileobj=response, mode="r|xz") as archive:
                for member in archive:
                    if not member.isfile() or not member.name.endswith(".h5"):
                        continue
                    name = Path(member.name).name
                    if not name.startswith("file"):
                        raise ValueError("Unexpected HDF5 archive member")
                    target = directory / name
                    names.append(name)
                    if readable_h5(target):
                        continue
                    if max_new_files is not None and count >= max_new_files:
                        complete = False
                        break
                    free = shutil.disk_usage(directory).free
                    if free < member.size + reserve_gb * 2**30:
                        raise RuntimeError("Insufficient storage for the whole split. Use a larger train_dir/val_dir; no files were deleted.")
                    partial = target.with_suffix(".h5.part")
                    stream = archive.extractfile(member)
                    with partial.open("wb") as output:
                        shutil.copyfileobj(stream, output, length=4 * 1024**2)
                    if partial.stat().st_size != member.size or not readable_h5(partial):
                        raise RuntimeError("Downloaded HDF5 failed validation: " + name)
                    os.replace(partial, target)
                    count += 1
                    print("Ready", name, "new files:", count, flush=True)
    except Exception:
        json_write(report, {"complete_archive": False, "archive_files": names,
                            "present_volumes": len(list(directory.glob("*.h5")))})
        raise
    result = {"complete_archive": complete, "archive_files": names,
              "present_volumes": len(list(directory.glob("*.h5")))}
    json_write(report, result)
    print("Download complete:", result["complete_archive"], "volumes:", result["present_volumes"])
    return result


def random_cartesian_mask(width, acceleration, center_fraction=.04, seed=None):
    """The official fastMRI RandomMaskFunc probability and center placement."""
    low = round(width * center_fraction)
    prob = (width / acceleration - low) / (width - low)
    if not 0 <= prob <= 1:
        raise ValueError("Incompatible acceleration/ACS")
    rng = np.random.RandomState(seed)
    line = rng.uniform(size=width) < prob
    pad = (width - low + 1) // 2
    line[pad:pad + low] = True
    return torch.from_numpy(line.astype(np.float32))[None, None, None, :]


class FastMRISlices(Dataset):
    """All train slices; one seeded slice per validation volume.

    Paper says crop complex images to320 then normalize magnitude to[0,1].
    Masks are simulated on that cropped image's320 Fourier grid. The paper does
    not fully describe crop/acquisition order; this choice is recorded.
    """
    def __init__(self, directory, training=True, size=320, seed=42, subjects=None):
        self.files = sorted(Path(directory).glob("*.h5"))
        if not self.files:
            raise RuntimeError("No HDF5 files in " + str(directory))
        self.size = size
        self.index = []
        rng = np.random.RandomState(seed)
        selected = self.files if training or subjects is None else [self.files[i] for i in rng.permutation(len(self.files))[:subjects]]
        for path in selected:
            with h5py.File(path, "r") as f:
                if "images_complex64" in f:
                    if f["images_complex64"].shape[1:] != (size, size):
                        raise ValueError("Cached image geometry differs")
                    count = f["images_complex64"].shape[0]
                elif "reconstruction_esc" not in f or "mask" in f or f["kspace"].ndim != 3:
                    raise ValueError("Expected fully sampled single-coil train/val file: " + path.name)
                else:
                    count = f["kspace"].shape[0]
            ids = range(count) if training else [int(rng.randint(count))]
            self.index.extend((path, i) for i in ids)

    def __len__(self):
        return len(self.index)

    def __getitem__(self, index):
        path, slice_id = self.index[index]
        with h5py.File(path, "r") as f:
            if "images_complex64" in f:
                x = torch.from_numpy(f["images_complex64"][slice_id])
                if not torch.isfinite(x).all():
                    raise ValueError("Non-finite cached MRI values")
                return complex_to_ri(x), path.name, slice_id
            k = torch.from_numpy(f["kspace"][slice_id].astype(np.complex64))
        x = ifft2c(k)
        h, w = x.shape
        if min(h, w) < self.size:
            raise ValueError("Image too small for320 crop")
        x = x[(h-self.size)//2:(h+self.size)//2,
              (w-self.size)//2:(w+self.size)//2]
        if not torch.isfinite(x).all():
            raise ValueError("Non-finite MRI values")
        scale = x.abs().amax().clamp_min(1e-12)
        x = x / scale
        return complex_to_ri(x), path.name, slice_id


def _split_provenance(directory, files):
    """Identify the available MRI sources from cache manifests or raw bytes.

    Filenames/slice indices remain a separate identity. Cache provenance is
    claimed only when its listed files and every cached header agree. A partial
    archive can identify its saved sources without claiming archive completion;
    the separate training/evaluation gates still enforce whole-data runs.
    Raw HDF5 inputs have no trusted cached-source record, so hash their bytes.
    """
    files = sorted((Path(path) for path in files), key=lambda path: path.name)
    manifest_path = Path(directory) / "download_manifest.json"
    saved = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
    headers = {}
    for path in files:
        with h5py.File(path, "r") as source:
            cached = "images_complex64" in source
            if cached:
                headers[path.name] = dict(
                    cached=True, cache_schema=str(source.attrs.get("ssdm_cache_schema", "")),
                    source_sha256=str(source.attrs.get("source_sha256", "")),
                    source_kspace_shape=list(source.attrs.get("source_kspace_shape", [])))
            else:
                headers[path.name] = dict(cached=False,
                                         source_kspace_shape=list(source["kspace"].shape))
    has_cache = any(header["cached"] for header in headers.values())
    cache_schema = None
    if has_cache:
        names = saved.get("archive_files", [])
        if (type(saved.get("complete_archive")) is not bool
                or not isinstance(saved.get("cache_schema"), str) or not saved["cache_schema"]
                or not isinstance(names, list) or not all(isinstance(name, str) for name in names)
                or sorted(names) != [path.name for path in files]
                or not isinstance(saved.get("volumes"), dict)):
            return None
        cache_schema = saved["cache_schema"]
    volumes = []
    for path in files:
        header = headers[path.name]
        shape = [int(value) for value in header["source_kspace_shape"]]
        if len(shape) != 3 or any(value < 1 for value in shape):
            return None
        if header["cached"]:
            recorded = saved["volumes"].get(path.name, {})
            if not isinstance(recorded, dict):
                return None
            digest = recorded.get("source_sha256")
            recorded_shape = recorded.get("source_kspace_shape")
            if (header["cache_schema"] != cache_schema
                    or not isinstance(digest, str) or len(digest) != 64
                    or any(value not in "0123456789abcdef" for value in digest)
                    or digest != header["source_sha256"]
                    or not isinstance(recorded_shape, (list, tuple))
                    or list(recorded_shape) != shape):
                return None
        else:
            digest = _file_sha256(path)
        volumes.append(dict(filename=path.name, source_sha256=digest,
                            source_kspace_shape=shape,
                            storage="cache" if header["cached"] else "raw"))
    if not volumes:
        return None
    identity = dict(schema="ssdm-data-provenance-v1", cache_schema=cache_schema,
                    volumes=volumes)
    return hashlib.sha256(json.dumps(identity, sort_keys=True,
                                    separators=(",", ":")).encode("utf8")).hexdigest()


def _check_training_provenance(saved_info, current_info):
    previous = saved_info.get("train_provenance_hash")
    current = current_info.get("train_provenance_hash")
    if not previous or not current or previous != current:
        raise ValueError("Training source provenance differs or cannot be verified; use a new output_dir for this experiment")


def dataset_inventory(cfg):
    train = FastMRISlices(cfg.train_dir, training=True, size=cfg.image_size)
    val = FastMRISlices(cfg.val_dir, training=False, size=cfg.image_size,
                       seed=cfg.seed, subjects=cfg.evaluation_subjects)
    overlap = set(p.name for p in train.files) & set(p.name for p in val.files)
    if overlap:
        raise ValueError("Train/val subject overlap")
    complete = []
    for directory in (cfg.train_dir, cfg.val_dir):
        manifest = Path(directory) / "download_manifest.json"
        saved = json.loads(manifest.read_text()) if manifest.exists() else {}
        names = saved.get('archive_files', [])
        complete.append(bool(saved.get('complete_archive') and names
                             and all(readable_h5(Path(directory)/name, full=False) for name in names)))
    train_identity = '\n'.join(f'{p.name}:{i}' for p,i in train.index)
    val_identity = '\n'.join(f'{p.name}:{i}' for p,i in val.index)
    info = dict(train_volumes=len(train.files), train_slices=len(train),
                validation_volumes=len(val.files), evaluation_subjects=len(val),
                complete_archives=all(complete), image_size=cfg.image_size,
                train_index_hash=hashlib.sha256(train_identity.encode()).hexdigest(),
                val_index_hash=hashlib.sha256(val_identity.encode()).hexdigest(),
                train_provenance_hash=_split_provenance(cfg.train_dir, train.files),
                val_provenance_hash=_split_provenance(cfg.val_dir, val.files),
                training_uses_validation=False)
    json_write(Path(cfg.output_dir) / "data_inventory.json", info)
    print(json.dumps(info, indent=2), flush=True)
    return train, val, info


def _training_data(cfg, allow_incomplete=False):
    train, val, info = dataset_inventory(cfg)
    if cfg.require_completed_archives and not info["complete_archives"] and not allow_incomplete:
        raise RuntimeError("Full-split preparation has not completed. Download both complete archives, or explicitly set allow_incomplete=True for a non-reproduction run.")
    if not info["train_provenance_hash"]:
        raise RuntimeError("Training source provenance cannot be verified. Complete the cache manifest, or use original raw HDF5 files whose contents can be hashed.")
    return train, info


def autocast_context(device, precision):
    return torch.autocast("cuda", dtype=torch.float16) if device.type == "cuda" and precision == "fp16" else contextlib.nullcontext()


def checkpoint_write(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    torch.save(payload, temporary)
    os.replace(temporary, path)


def _resume(path, model, optimizer, device, cfg, stage, data_info):
    if not path.exists():
        return 0, 0, 0
    # Keep checkpoint tensors onCPU to avoid duplicating the entire model onGPU.
    state = torch.load(path, map_location="cpu", weights_only=False, mmap=True)
    if state["stage"] != stage or state["config"] != asdict(cfg):
        raise ValueError("Checkpoint stage/config differs; use a different output_dir for changed experiments")
    if state["data_info"]["train_index_hash"] != data_info["train_index_hash"]:
        raise ValueError("Training data changed; use a new output_dir instead of treating subset epochs as full-data epochs")
    _check_training_provenance(state["data_info"], data_info)
    model.load_state_dict(state["model"])
    optimizer.load_state_dict(state["optimizer"])
    # Adam keeps CPU step tensors as-is; detach them from the whole mmap file.
    for optimizer_state in optimizer.state.values():
        for key, value in optimizer_state.items():
            if torch.is_tensor(value) and value.device.type == "cpu":
                optimizer_state[key] = value.detach().clone()
    torch.set_rng_state(state["rng_cpu"].cpu())
    if device.type == "cuda" and "rng_cuda" in state:
        torch.cuda.set_rng_state_all([s.cpu() for s in state["rng_cuda"]])
    return state["next_epoch"], state["next_batch"], state["updates"]


def _save_training(path, model, optimizer, cfg, stage, epoch, batch, updates, data_info, extra=None):
    payload = dict(stage=stage, config=asdict(cfg), model=model.state_dict(),
                   optimizer=optimizer.state_dict(), next_epoch=epoch, next_batch=batch,
                   updates=updates, data_info=data_info, rng_cpu=torch.get_rng_state(),
                   completed=epoch >= (cfg.cdl_epochs if stage == "cdl" else cfg.diffusion_epochs))
    if torch.cuda.is_available():
        payload["rng_cuda"] = torch.cuda.get_rng_state_all()
    if extra:
        payload.update(extra)
    checkpoint_write(path, payload)
    json_write(path.parent / (stage + "_status.json"), {k: payload[k] for k in ("stage", "next_epoch", "next_batch", "updates", "completed", "data_info")})


def _validated_stop_at(stop_at):
    if stop_at is None:
        return None
    stop_at = float(stop_at)
    if not np.isfinite(stop_at):
        raise ValueError("stop_at must be a finite Unix timestamp or None")
    return stop_at


def _deadline_reached(stop_at):
    return stop_at is not None and time.time() >= stop_at


def _next_training_position(epoch, batch_id, batches):
    return (epoch + 1, 0) if batch_id + 1 == batches else (epoch, batch_id + 1)


def _capture_training_rng(stop_at):
    if stop_at is None:
        return None
    return (torch.get_rng_state(),
            torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None)


def _restore_training_rng(snapshot):
    if snapshot is not None:
        torch.set_rng_state(snapshot[0])
        if snapshot[1] is not None:
            torch.cuda.set_rng_state_all(snapshot[1])


def _optimizer_step_before_deadline(stop_at, device, step):
    if stop_at is not None:
        # Wait for backward before checking wall time; never launch a new step
        # after the cutoff. An optimizer call already started is atomic here.
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        if _deadline_reached(stop_at):
            return False
    step()
    return True


def train_cdl(cfg=None, allow_incomplete=False, max_updates=None, stop_at=None):
    """Train towards100epochs; stop_at limits this call, outside saved config.

    stop_at is a Unix timestamp for ending updates. The caller must leave time
    after it for the last backward/atomic checkpoint write to finish.
    """
    cfg = cfg or ExperimentConfig()
    stop_at = _validated_stop_at(stop_at)
    if _deadline_reached(stop_at):
        print("CDL deadline reached before training; checkpoint unchanged.", flush=True)
        return None
    seed_everything(cfg.seed)
    train, data_info = _training_data(cfg, allow_incomplete)
    if _deadline_reached(stop_at):
        print("CDL deadline reached during data checks; checkpoint unchanged.", flush=True)
        return None
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = CoupledDictionary().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=cfg.cdl_lr, foreach=False)
    weights = CDLLossWeights()
    path = Path(cfg.output_dir) / "cdl_latest.pt"
    if _deadline_reached(stop_at):
        print("CDL deadline reached before checkpoint loading; checkpoint unchanged.", flush=True)
        return None
    epoch0, batch0, updates = _resume(path, model, optimizer, device, cfg, "cdl", data_info)
    this_run = 0
    t0 = time.time()
    next_epoch, next_batch = epoch0, batch0
    checkpoint_dirty = False

    def finish_deadline():
        if checkpoint_dirty:
            _save_training(path, model, optimizer, cfg, "cdl", next_epoch, next_batch,
                           updates, data_info, {"loss_weights": asdict(weights)})
        print("CDL deadline reached;", "progress saved." if checkpoint_dirty else "checkpoint unchanged.",
              "Resume the same100epoch goal.",
              "new_updates", this_run, "next_epoch", next_epoch,
              "next_batch", next_batch, flush=True)

    model.train()
    for epoch in range(epoch0, cfg.cdl_epochs):
        if _deadline_reached(stop_at):
            finish_deadline()
            return model
        loader = DataLoader(train, batch_size=cfg.batch_images, shuffle=True,
                            generator=torch.Generator().manual_seed(cfg.seed+epoch), num_workers=0)
        for batch_id, (x, _, _) in enumerate(loader):
            if _deadline_reached(stop_at):
                finish_deadline()
                return model
            if epoch == epoch0 and batch_id < batch0:
                continue
            batch_rng = _capture_training_rng(stop_at)
            x = x.to(device)
            masks = [random_cartesian_mask(cfg.image_size, cfg.accelerations[(updates+i)%len(cfg.accelerations)], cfg.center_fraction, cfg.seed+updates+i) for i in range(len(x))]
            mask = torch.cat(masks).to(device)
            y = mask[:, 0] * fft2c(ri_to_complex(x))
            under = complex_to_ri(ifft2c(y))
            optimizer.zero_grad(set_to_none=True)
            # Stage1 is small; keep thresholds, FFTs and norms inFP32.
            loss, terms, _, _ = coupled_dictionary_loss(model, x, under, y, mask, weights)
            if not torch.isfinite(loss):
                raise RuntimeError("Non-finite CDL loss")
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1)
            if not _optimizer_step_before_deadline(stop_at, device, optimizer.step):
                # Replay this uncommitted batch with the same RNG when resuming.
                optimizer.zero_grad(set_to_none=True)
                _restore_training_rng(batch_rng)
                finish_deadline()
                return model
            updates += 1
            this_run += 1
            next_epoch, next_batch = _next_training_position(epoch, batch_id, len(loader))
            checkpoint_dirty = True
            if this_run == 1 or updates % 25 == 0:
                print("CDL", f"epoch {epoch+1}/{cfg.cdl_epochs}", "step", updates,
                      {k: round(float(v.detach()), 6) for k,v in terms.items()}, flush=True)
            stop = ((max_updates is not None and this_run >= max_updates)
                    or (cfg.session_seconds and time.time()-t0 >= cfg.session_seconds)
                    or _deadline_reached(stop_at))
            if updates % cfg.checkpoint_every == 0 or stop:
                _save_training(path, model, optimizer, cfg, "cdl", next_epoch, next_batch, updates, data_info,
                               {"loss_weights": asdict(weights)})
                checkpoint_dirty = False
            if stop:
                print("CDL progress saved. Run this cell again to continue the same100epoch goal.", "seconds", round(time.time()-t0,1))
                return model
        if checkpoint_dirty or (next_epoch, next_batch) != (epoch + 1, 0):
            _save_training(path, model, optimizer, cfg, "cdl", epoch+1, 0, updates, data_info,
                           {"loss_weights": asdict(weights)})
        next_epoch, next_batch = epoch + 1, 0
        checkpoint_dirty = False
        print("CDL epoch complete", epoch+1, "seconds", round(time.time()-t0,1), flush=True)
    return model


def load_dictionary(cfg, device, allow_partial=False):
    path = Path(cfg.output_dir) / "cdl_latest.pt"
    if not path.exists():
        raise RuntimeError("Train the CDL stage first")
    state = torch.load(path, map_location=device, weights_only=False)
    if state['config'] != asdict(cfg):
        raise ValueError('CDL checkpoint/config differs; use the matching experiment configuration')
    current = FastMRISlices(cfg.train_dir, training=True, size=cfg.image_size)
    identity = '\n'.join(f'{p.name}:{i}' for p,i in current.index)
    if state['data_info']['train_index_hash'] != hashlib.sha256(identity.encode()).hexdigest():
        raise ValueError('CDL was trained with a different data index; train a new dictionary for this experiment')
    _check_training_provenance(state['data_info'], dict(
        train_provenance_hash=_split_provenance(cfg.train_dir, current.files)))
    if not state["completed"] and not allow_partial:
        raise RuntimeError("CDL100epochs not complete; stage2 must use a frozen, fully trainedCDL. allow_partial=True is only for a labeled functional check.")
    model = CoupledDictionary().to(device).eval().requires_grad_(False)
    model.load_state_dict(state["model"])
    return model, state


def train_diffusion(cfg=None, allow_incomplete=False, allow_partial_cdl=False, max_updates=None, stop_at=None):
    """stop_at limits this call's updates without changing saved100epoch config."""
    cfg = cfg or ExperimentConfig()
    stop_at = _validated_stop_at(stop_at)
    if _deadline_reached(stop_at):
        print("DDPM deadline reached before training; checkpoint unchanged.", flush=True)
        return None
    if not torch.cuda.is_available():
        raise RuntimeError("This full-size backbone requiresGPU training; there is no automatic smaller replacement")
    seed_everything(cfg.seed)
    train, data_info = _training_data(cfg, allow_incomplete)
    if _deadline_reached(stop_at):
        print("DDPM deadline reached during data checks; checkpoint unchanged.", flush=True)
        return None
    device = torch.device("cuda")
    cdl, cdl_state = load_dictionary(cfg, device, allow_partial_cdl)
    if _deadline_reached(stop_at):
        print("DDPM deadline reached before full backbone allocation; checkpoint unchanged.", flush=True)
        return None
    model = SSDMUNet().to(device).train()
    print(json.dumps(model.architecture_report(), indent=2), flush=True)
    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg.diffusion_lr, weight_decay=0, foreach=False)
    scaler = torch.amp.GradScaler("cuda", enabled=cfg.precision == "fp16", init_scale=1024)
    path = Path(cfg.output_dir) / "diffusion_latest.pt"
    if _deadline_reached(stop_at):
        print("DDPM deadline reached before checkpoint loading; checkpoint unchanged.", flush=True)
        return None
    epoch0, batch0, updates = _resume(path, model, optimizer, device, cfg, "diffusion", data_info)
    cdl_hash = hashlib.sha256(Path(cfg.output_dir, "cdl_latest.pt").read_bytes()).hexdigest()
    if path.exists():
        prior = torch.load(path, map_location="cpu", weights_only=False, mmap=True)
        if prior["cdl_hash"] != cdl_hash:
            raise ValueError("CDL changed after stage2 began; use a new output_dir")
        if "scaler" in prior:
            scaler.load_state_dict(prior["scaler"])
        del prior
    ac = (1-torch.linspace(cfg.beta_start,cfg.beta_end,cfg.timesteps,device=device)).cumprod(0)
    this_run = 0
    t0 = time.time()
    consecutive_skips = 0
    extra = {"backbone_config": asdict(model.cfg), "cdl_hash": cdl_hash,
             "cdl_completed": cdl_state["completed"], "scaler": scaler.state_dict()}
    next_epoch, next_batch = epoch0, batch0
    checkpoint_dirty = False

    def finish_deadline():
        if checkpoint_dirty:
            extra["scaler"] = scaler.state_dict()
            _save_training(path, model, optimizer, cfg, "diffusion", next_epoch, next_batch,
                           updates, data_info, extra)
        print("DDPM deadline reached;", "progress saved." if checkpoint_dirty else "checkpoint unchanged.",
              "Resume the same100epoch goal.",
              "new_updates", this_run, "next_epoch", next_epoch,
              "next_batch", next_batch, flush=True)

    for epoch in range(epoch0, cfg.diffusion_epochs):
        if _deadline_reached(stop_at):
            finish_deadline()
            return model
        loader = DataLoader(train, batch_size=cfg.batch_images, shuffle=True,
                            generator=torch.Generator().manual_seed(cfg.seed+epoch), num_workers=0)
        for batch_id, (x, _, _) in enumerate(loader):
            if _deadline_reached(stop_at):
                finish_deadline()
                return model
            if epoch == epoch0 and batch_id < batch0:
                continue
            batch_rng = _capture_training_rng(stop_at)
            optimizer.zero_grad(set_to_none=True)
            x = x.to(device)
            with torch.no_grad():
                clean = cdl(x).subspaces.detach()
            t = torch.randint(cfg.timesteps,(len(x),),device=device)
            a = ac[t].reshape(-1,1,1,1,1)
            noise = torch.randn_like(clean)
            noisy = a.sqrt()*clean + (1-a).sqrt()*noise
            # CPU activation storage and checkpoint recomputation preserve model,
            # component grouping, image resolution and the objective on a16GiBGPU.
            offload = torch.autograd.graph.save_on_cpu(pin_memory=True) if cfg.activation_cpu_offload else contextlib.nullcontext()
            with offload:
                with autocast_context(device,cfg.precision):
                    eps = model(noisy,t)
                eps = eps.float()
                noise_loss = (eps-noise).square().mean()
                # Eq8-consistent Tweedie inversion; Eq9/Algorithm1 have ambiguous alpha notation.
                x0 = (noisy-(1-a).sqrt()*eps)/a.sqrt()
                rec_loss = (x0.sum(1)-x).square().sum(1).mean()
                loss = noise_loss + cfg.reconstruction_weight*rec_loss
            if not torch.isfinite(loss):
                raise RuntimeError("Non-finite diffusion loss")
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            grad_norm = nn.utils.clip_grad_norm_(model.parameters(),1,foreach=False)
            if not scaler.is_enabled() and not torch.isfinite(grad_norm):
                raise RuntimeError("Non-finite diffusion gradients; no optimizer update was performed")
            scale_before = scaler.get_scale()
            if not _optimizer_step_before_deadline(stop_at, device, lambda: scaler.step(optimizer)):
                optimizer.zero_grad(set_to_none=True)
                _restore_training_rng(batch_rng)
                finish_deadline()
                return model
            scaler.update()
            next_epoch, next_batch = _next_training_position(epoch, batch_id, len(loader))
            checkpoint_dirty = True
            if scaler.is_enabled() and scaler.get_scale() < scale_before:
                consecutive_skips += 1
                print("DDPM skipped non-finite gradients; no update counted.",
                      "scale", scaler.get_scale(), flush=True)
                if consecutive_skips >= 8:
                    raise RuntimeError("Eight consecutive diffusion updates were skipped; training is not verified")
                if _deadline_reached(stop_at):
                    finish_deadline()
                    return model
                continue
            consecutive_skips = 0
            updates += 1
            this_run += 1
            if this_run <= 2 or updates % 25 == 0:
                print("DDPM", f"epoch {epoch+1}/{cfg.diffusion_epochs}", "step",updates,
                      "noise",round(float(noise_loss.detach()),6),"reconstruction",round(float(rec_loss.detach()),6),
                      "gradient_norm",round(float(grad_norm),6),"optimizer_update",True,
                      "seconds_per_update",round((time.time()-t0)/this_run,2),
                      "GPU_GiB",round(torch.cuda.memory_allocated()/2**30,3), flush=True)
            stop = ((max_updates is not None and this_run >= max_updates)
                    or (cfg.session_seconds and time.time()-t0 >= cfg.session_seconds)
                    or _deadline_reached(stop_at))
            extra = {"backbone_config": asdict(model.cfg), "cdl_hash": cdl_hash,
                     "cdl_completed": cdl_state["completed"], "scaler": scaler.state_dict()}
            if updates % cfg.checkpoint_every == 0 or stop:
                _save_training(path,model,optimizer,cfg,"diffusion",next_epoch,next_batch,updates,data_info,extra)
                checkpoint_dirty = False
            if stop:
                print("DDPM progress saved. Run this cell again to continue the same100epoch goal.","seconds",round(time.time()-t0,1), flush=True)
                return model
        extra["scaler"] = scaler.state_dict()
        if checkpoint_dirty or (next_epoch, next_batch) != (epoch + 1, 0):
            _save_training(path,model,optimizer,cfg,"diffusion",epoch+1,0,updates,data_info,extra)
        next_epoch, next_batch = epoch + 1, 0
        checkpoint_dirty = False
        print("DDPM epoch complete",epoch+1,"seconds",round(time.time()-t0,1),flush=True)
    return model


def metric_values(reference, result):
    from skimage.metrics import structural_similarity
    reference, result = np.asarray(reference,dtype=np.float64), np.asarray(result,dtype=np.float64)
    if not np.isfinite(reference).all() or not np.isfinite(result).all():
        raise FloatingPointError("Non-finite image cannot be scored")
    mse = np.mean((reference-result)**2)
    return {"PSNR":float(-10*np.log10(max(mse,1e-30))),
            "SSIM":float(structural_similarity(reference,result,data_range=1.0)),
            "MAE":float(np.mean(np.abs(reference-result)))}


def _file_sha256(path):
    """Hash large checkpoints without loading their bytes into host RAM."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(8 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()


def _evaluation_case_key(name, slice_id, acceleration):
    return json.dumps([str(name), int(slice_id), int(acceleration)], separators=(",", ":"))


def _evaluation_sampler_seed(seed, name, slice_id, acceleration):
    identity = json.dumps(["ssdm-sampler-v1", int(seed), str(name),
                           int(slice_id), int(acceleration)], separators=(",", ":"))
    # Reset each case independently, so skipping completed cases cannot change
    # subsequent Gaussian initialization or stochastic-resampling noise.
    return int.from_bytes(hashlib.sha256(identity.encode("utf8")).digest()[:4], "big")


def _evaluation_case_plan(val, cfg):
    plan = []
    # Raw HDF5 and the lossless cache preserve the original filename and the
    # (path,slice) index. Building a plan does not read199 image slices.
    for index, (path, slice_id) in enumerate(val.index):
        name = path.name
        for acceleration in cfg.accelerations:
            acceleration = int(acceleration)
            plan.append(dict(index=index, file=str(name), slice=int(slice_id),
                             R=acceleration, mask_seed=cfg.seed + index,
                             sampler_seed=_evaluation_sampler_seed(
                                 cfg.seed, name, slice_id, acceleration),
                             case_key=_evaluation_case_key(name, slice_id, acceleration),
                             array_file=f"cases/{index:04d}_R{acceleration}.npz"))
    return plan


def _write_evaluation_arrays(path, experiment_key, case, record, **arrays):
    """Arrays and metrics commit atomically before the progress JSON is updated."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".npz.tmp")
    with temporary.open("wb") as output:
        np.savez_compressed(output, experiment_key=np.asarray(experiment_key),
                            case_key=np.asarray(case["case_key"]),
                            record_json=np.asarray(json.dumps(record, sort_keys=True)),
                            **arrays)
    os.replace(temporary, path)
    return _file_sha256(path)


def _read_evaluation_case(path, experiment_key, case, saved_record=None):
    """Trust only matching identities and intact arrays; recover orphan NPZs."""
    path = Path(path)
    if not path.exists():
        return None
    try:
        array_hash = _file_sha256(path)
        if saved_record is not None and saved_record.get("array_sha256") != array_hash:
            return None
        with np.load(path, allow_pickle=False) as saved:
            if (str(saved["experiment_key"].item()) != experiment_key
                    or str(saved["case_key"].item()) != case["case_key"]):
                return None
            record = json.loads(str(saved["record_json"].item()))
            for field in ("file", "slice", "R", "mask_seed", "sampler_seed", "case_key", "array_file"):
                if record.get(field) != case[field]:
                    return None
            if saved_record is not None:
                previous = {k: v for k, v in saved_record.items() if k != "array_sha256"}
                if previous != record:
                    return None
            else:
                # A disconnect after NPZ commit but before JSON commit must not
                # throw away a completed sampling run. Verify the orphan's CRCs,
                # finite image values and dimensions before recovering metrics.
                shapes = [saved[k].shape for k in ("reference", "zero_filled", "ssdm")]
                if len(set(shapes)) != 1 or len(shapes[0]) != 2:
                    return None
                if not all(np.isfinite(saved[k]).all() for k in
                           ("reference", "zero_filled", "ssdm", "recovered_complex", "mask")):
                    return None
            metrics = [record["DC"], record["actual_R"]]
            metrics.extend(record[method][metric] for method in ("zero_filled", "ssdm")
                           for metric in ("PSNR", "SSIM", "MAE"))
            if not np.isfinite(metrics).all():
                return None
        record["array_sha256"] = array_hash
        return record
    except (OSError, ValueError, KeyError, EOFError, zipfile.BadZipFile):
        return None


def _render_first_evaluation(plan, completed, run_dir, output_dir):
    """Render the first comparison entirely from committed arrays, after resume."""
    import matplotlib.pyplot as plt
    first = [case for case in plan if case["index"] == 0]
    if not first or any(case["case_key"] not in completed for case in first):
        return
    fig, axes = plt.subplots(len(first), 4, figsize=(14, 3.5 * len(first)), squeeze=False)
    for row, case in enumerate(first):
        with np.load(Path(run_dir) / case["array_file"], allow_pickle=False) as saved:
            reference, zero_filled, magnitude = (
                saved["reference"], saved["zero_filled"], saved["ssdm"])
        images = (reference, zero_filled, magnitude, np.abs(reference - magnitude))
        titles = ("Reference", f"Zero-filled R={case['R']}", "SSDM equations", "Absolute error")
        for axis, image, title in zip(axes[row], images, titles):
            axis.imshow(image, cmap="gray", vmin=0, vmax=.3 if title == "Absolute error" else 1)
            axis.set_title(title)
            axis.axis("off")
    fig.tight_layout()
    image_path = Path(run_dir) / "reconstruction.png"
    fig.savefig(image_path, dpi=150)
    shutil.copy2(image_path, Path(output_dir) / "reconstruction.png")
    plt.show()
    plt.close(fig)


def evaluate(cfg=None, allow_partial=False, max_subjects=None, sampler_cfg=None):
    """Resumable paired evaluation; no reference image enters the sampler.

    Each checkpoint/config/data/sampler combination has its own directory.
    Completed cases are skipped only when their exact identities and saved
    arrays match. max_subjects limits new work, without discarding prior results.
    """
    cfg = cfg or ExperimentConfig()
    sampler_cfg = sampler_cfg or SamplerConfig()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    _, val, info = dataset_inventory(cfg)
    diffusion_path = Path(cfg.output_dir) / "diffusion_latest.pt"
    dictionary_path = Path(cfg.output_dir) / "cdl_latest.pt"
    print("Hashing checkpoints for exact evaluation identity (streaming, without a RAM copy).", flush=True)
    diffusion_hash = _file_sha256(diffusion_path)
    dictionary_hash = _file_sha256(dictionary_path)
    state = torch.load(diffusion_path, map_location="cpu", weights_only=False, mmap=True)
    if state["config"] != asdict(cfg) or state["data_info"]["train_index_hash"] != info["train_index_hash"]:
        raise ValueError("Diffusion checkpoint/config/training data differs from the selected experiment")
    _check_training_provenance(state["data_info"], info)
    if not info["val_provenance_hash"]:
        raise RuntimeError("Validation source provenance cannot be verified; existing evaluation cases cannot safely be reused")
    if state["cdl_hash"] != dictionary_hash:
        raise ValueError("The dictionary changed after diffusion training; these weights cannot be paired")
    complete = (state["completed"] and state["cdl_completed"] and info["complete_archives"]
                and len(val) >= cfg.evaluation_subjects)
    if not complete and not allow_partial:
        raise RuntimeError("Full training/data/evaluation conditions not completed. allow_partial=True must be labeled as incomplete learning, not a reproduction result.")

    plan = _evaluation_case_plan(val, cfg)
    source_directory = Path(__file__).resolve().parent
    sources = {name: _file_sha256(source_directory / name)
               for name in ("ssdm_sampling.py", "ssdm_backbone.py", "ssdm_cdl.py", "ssdm_experiment.py")}
    identity = dict(schema=3, config=asdict(cfg), sampler=asdict(sampler_cfg),
                    cdl_checkpoint_sha256=dictionary_hash,
                    diffusion_checkpoint_sha256=diffusion_hash,
                    train_index_hash=info["train_index_hash"],
                    val_index_hash=info["val_index_hash"],
                    train_provenance_hash=info["train_provenance_hash"],
                    val_provenance_hash=info["val_provenance_hash"], cases=plan,
                    inference_sources=sources, torch_version=str(torch.__version__),
                    sampling_device_type=device.type,
                    mask_seed_policy="cfg.seed + validation index; same seed for R8/R16",
                    sampler_seed_policy="sha256(base seed, file, slice, R), reset per case")
    # JSON canonicalization also makes dataclass tuples equal to loaded lists.
    identity = json.loads(json.dumps(identity, sort_keys=True))
    experiment_key = hashlib.sha256(json.dumps(identity, sort_keys=True,
                                             separators=(",", ":")).encode("utf8")).hexdigest()
    run_dir = Path(cfg.output_dir) / "evaluations" / experiment_key
    progress_path = run_dir / "progress.json"
    completed = {}
    previous_records = {}
    if progress_path.exists():
        previous = json.loads(progress_path.read_text(encoding="utf8"))
        if previous.get("experiment_key") != experiment_key or previous.get("identity") != identity:
            raise ValueError("Evaluation progress identity differs; refusing to mix experiments")
        for record in previous.get("records", []):
            if record["case_key"] in previous_records:
                raise ValueError("Duplicate cases in evaluation progress")
            previous_records[record["case_key"]] = record
    for case in plan:
        record = _read_evaluation_case(run_dir / case["array_file"], experiment_key,
                                       case, previous_records.get(case["case_key"]))
        if record is not None:
            completed[case["case_key"]] = record

    def saved_records():
        return [completed[case["case_key"]] for case in plan if case["case_key"] in completed]

    def save_progress():
        progress = dict(schema=3, experiment_key=experiment_key, identity=identity,
                        completed_cases=len(completed), expected_cases=len(plan),
                        evaluation_completed=len(completed) == len(plan), records=saved_records())
        json_write(progress_path, progress)
        json_write(Path(cfg.output_dir) / "evaluation_progress.json", progress)

    save_progress()
    subject_limit = len(val) if max_subjects is None else min(len(val), max(0, int(max_subjects)))
    target_cases = [case for case in plan if case["index"] < subject_limit]
    pending = [case for case in target_cases if case["case_key"] not in completed]
    print("Evaluation", experiment_key[:12], "resuming", len(completed), "/",
          len(plan), "completed cases;", len(pending), "cases pending in this call", flush=True)
    # Restore the comparison immediately even when later subjects still need
    # sampling (for example, a disconnect after both first-subject NPZ commits).
    _render_first_evaluation(plan, completed, run_dir, cfg.output_dir)
    if pending:
        cdl, _ = load_dictionary(cfg, device, allow_partial)
        model = SSDMUNet(BackboneConfig(**state["backbone_config"])).to(device).eval()
        model.load_state_dict(state["model"])
    del state
    if pending:
        def predictor(x, t):
            with autocast_context(device, cfg.precision):
                eps = model(x, t)
            return eps.float()

        betas = torch.linspace(cfg.beta_start, cfg.beta_end, cfg.timesteps, device=device)
        for index in range(subject_limit):
            cases = [case for case in pending if case["index"] == index]
            if not cases:
                continue
            x, name, slice_id = val[index]
            x = x[None].to(device)
            reference = ri_to_complex(x)[0].abs().cpu().numpy()
            for case in cases:
                R = case["R"]
                if str(name) != case["file"] or int(slice_id) != case["slice"]:
                    raise ValueError("Validation case changed while evaluation was running")
                mask = random_cartesian_mask(cfg.image_size, R, cfg.center_fraction,
                                              case["mask_seed"]).to(device)
                y = mask[:, 0] * fft2c(ri_to_complex(x))
                zf = ifft2c(y)
                with torch.no_grad():
                    anchors = mask * fft2c(ri_to_complex(cdl(complex_to_ri(zf)).subspaces))
                # Reference is used to simulate y and compute metrics. Only y,
                # mask and undersampled anchors enter reconstruction.
                seed_everything(case["sampler_seed"])
                started = time.time()

                def progress(k, t, u, components):
                    if k % 25 == 0:
                        print("Sampling", name, "R", R, "step", k, "/",
                              sampler_cfg.inference_steps, flush=True)

                recovered, _ = sample_ssdm(predictor, y, mask, anchors, betas, sampler_cfg, progress)
                recovered_complex = ri_to_complex(recovered)[0].cpu().numpy()
                magnitude = np.abs(recovered_complex)
                zero_filled = zf[0].abs().cpu().numpy()
                dc = float((mask[:, 0] * fft2c(ri_to_complex(recovered)) - y).norm()
                           / y.norm().clamp_min(1e-12))
                if not np.isfinite(dc):
                    raise FloatingPointError("Non-finite measured k-space error")
                record = {k: case[k] for k in
                          ("file", "slice", "R", "mask_seed", "sampler_seed", "case_key", "array_file")}
                record.update(actual_R=float(cfg.image_size / mask.sum()), DC=dc,
                              zero_filled=metric_values(reference, zero_filled),
                              ssdm=metric_values(reference, magnitude),
                              sampling_seconds=round(time.time() - started, 4),
                              runtime=dict(torch_version=str(torch.__version__), device=device.type,
                                           GPU=torch.cuda.get_device_name() if device.type == "cuda" else None))
                record["paired_difference"] = {metric: record["ssdm"][metric] - record["zero_filled"][metric]
                                               for metric in ("PSNR", "SSIM", "MAE")}
                record["array_sha256"] = _write_evaluation_arrays(
                    run_dir / case["array_file"], experiment_key, case, record,
                    reference=reference, zero_filled=zero_filled, ssdm=magnitude,
                    recovered_complex=recovered_complex, mask=mask.cpu().numpy())
                completed[case["case_key"]] = record
                save_progress()
                print(json.dumps(record), flush=True)
            if index == 0:
                _render_first_evaluation(plan, completed, run_dir, cfg.output_dir)
    records = saved_records()
    actual_subjects = len(set(record["file"] for record in records))
    paper_protocol = (cfg.image_size == 320 and cfg.cdl_epochs == 100
                      and cfg.diffusion_epochs == 100 and cfg.evaluation_subjects == 200
                      and cfg.center_fraction == .04 and tuple(cfg.accelerations) == (8, 16)
                      and sampler_cfg.inference_steps == 100)
    configured_result = complete and len(completed) == len(plan) and actual_subjects >= cfg.evaluation_subjects
    full_result = configured_result and paper_protocol
    result = dict(full_experiment_completed=full_result,
                  configured_experiment_completed=configured_result,
                  paper_protocol_matched=paper_protocol, evaluation_completed=len(completed) == len(plan),
                  experiment_key=experiment_key, data=info, config=asdict(cfg),
                  cdl_checkpoint_sha256=dictionary_hash,
                  diffusion_checkpoint_sha256=diffusion_hash,
                  diffusion_checkpoint=str(diffusion_path), evaluation_directory=str(run_dir),
                  sampler=asdict(sampler_cfg), records=records)
    json_write(run_dir / "evaluation.json", result)
    json_write(Path(cfg.output_dir) / "evaluation.json", result)
    for R in cfg.accelerations:
        for method in ("zero_filled", "ssdm"):
            group = [record[method] for record in records if record["R"] == R]
            if group:
                print("R", R, method, {metric: float(np.mean([row[metric] for row in group]))
                                      for metric in ("PSNR", "SSIM", "MAE")})
    print("Evaluation cases completed:", len(completed), "/", len(plan), flush=True)
    print("Full experiment completed:", full_result, flush=True)
    return result
