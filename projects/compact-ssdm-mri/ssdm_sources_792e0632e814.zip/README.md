# SSDM 논문 수식 기반 구현

이 구현은 사용자가 제공한 논문의 명시된 수식과 설정을 반영합니다. 저자의 SSDM 소스/학습 가중치는 공개 검색에서 확인되지 않았습니다. 공개되지 않은 세부 설정을 임의로 원본과 동일하다고 표시하지 않습니다.

사용자가 추가 저장을 생략하고 다음 단계로 진행하도록 요청하여, 현재 노트북의 SKIP_DOWNLOAD=True는 이미 저장된 train 자료만 사용합니다. 모델 크기·320해상도·각100epochs 목표는 유지하고, 결과는 available_train_run에 보존합니다. 전체973명 학습 자료 재현으로 표시하지 않습니다. 전체 데이터 준비를 다시 원할 때만 SKIP_DOWNLOAD=False로 변경합니다.

## 반영한 내용

- 320×320 복소 영상, real/imag 채널 2, 희소 채널 8, LISTA 12블록.
- Eq13의 Q1→imGeLU→Q2 보정 및 공간별 soft threshold. Appendix A.1의 초기 임계값 1×0.8^j.
- Eq3–6의 자기 재구성, L1, 성분별 측정 위치 결합, 전체 측정 일치, 비관측 에너지, 직교성 손실.
- CDL 학습 후 고정, 완전한 train 영상의 성분으로 unconditional DDPM 학습. 노이즈 MSE와 성분 합 재구성 손실.
- 공식 DDS/ADM 361,423,618개 파라미터 backbone, 최종 encoder와 middle의 성분 간 attention. 실제 전체는 369,824,514개로 논문의 367.4M과 차이가 있습니다.
- Eq11의 conjugate gradient, Eq10의 autograd gradient descent, 100회 DDIM, Eq12의 Gaussian stochastic resampling.
- 전체 train 파일의 모든 슬라이스를 읽으며 두 단계 각각100epochs, R8/16, ACS4%, 검증 피험자당 한 슬라이스. 실제 공식 knee val199명 모두 평가하고 논문의200명과의 차이를 기록합니다.
- 동일 측정 마스크·기준 스케일로 zero-filled와 비교, PSNR/SSIM/MAE·측정 일치 오차 출력.
- 체크포인트 재개, 원본 SHA256에 기반한 데이터 변경 감지, 두 단계 완료 여부와 전체 자료 준비 여부 기록. 평가는 체크포인트·설정·전처리/지표를 포함한 소스·마스크·seed를 확인하고 저장된 증례를 건너뛰어 재개합니다. 증례별 실제 영상과 지표도 보존합니다. Adam 상태를 재개할 때 작은 CPU step 값을 복사하여 이전 체크포인트의 전체 mmap 참조가 남지 않게 합니다.
- T4에서 FP16 연산, gradient checkpointing, CPU activation offload를 사용합니다. FP32 모델 가중치와 AdamW 상태를 유지하며 overflow로 건너뛴 optimizer step은 업데이트로 세지 않습니다. 본 학습 전에 실제320영상으로 두 번 연속 optimizer 업데이트의 메모리 사용을 검증하고 시험 가중치를 버립니다. 이것은 성능 평가가 아닙니다.

## 공개되지 않았거나 모호한 부분

- optimizer, 학습률, batch size, loss의 수치 가중치·reduction, CDL kernel/padding/z0/초기화, threshold attention 세부 구조는 구현 선택입니다.
- 성분 attention의 정확한 축·projection·head 수는 미공개입니다. 이 구현은 같은 위치의8성분 사이 attention을 사용하며 다른 피험자를 섞지 않습니다.
- DDS 공개 설정의 attention factor20은 encoder의2배 downsample 단계와 일치하지 않아 native spatial attention은 middle에만 있습니다. 공개 설정을 유지합니다.
- 논문 Eq9/Algorithm1의 alpha 표기가 Eq8과 일관되지 않아 Tweedie와 DDIM은 누적 alpha와 current t→previous u 관례를 명시적으로 사용합니다.
- Eq12에 인쇄된 sigma 공식과 인용된 ReSample 저자 코드의 공식은 다릅니다. 기본값은 paper_literal이며 resample_reference를 별도로 선택할 수 있습니다. gamma/C/solver 설정은 미공개 값입니다.
- 정규화한320complex crop의 Fourier grid에 마스크를 적용합니다. 정확한 native acquisition 전처리 순서는 논문에 충분히 설명되지 않았습니다.
- 공식 fastMRI knee val은199개이고 논문은200개를 기술합니다. 실제199개 전체를 평가하며 configured_experiment_completed는 전체 준비·두100epochs·199명 평가 완료 여부, paper_protocol_matched/full_experiment_completed는 논문의200명 조건까지 동일한지 구분합니다. 본 코드가 제공하는 비교는 zero-filled이며, 논문의 다른5baseline 전체를 재현한 것은 아닙니다.

## 실행

Colab 노트북에서 설치/검증 → 자료 준비 → CDL100epochs → diffusion100epochs → 평가 순서로 진행합니다. Python torch2.x, numpy, h5py, matplotlib, scikit-image가 필요하며 Colab 기본 런타임에 포함됩니다. 작은 모델로 자동 대체하지 않습니다.

노트북은 정확히8개 코드 셀입니다. 1설치/설정 →2전체 데이터·저장소 →3검증·zero-filled →4CDL100epochs →5DDPM100epochs →6물리 안내 sampler →7전체 val 성능평가 →8결과표 순서입니다. 이전64×64모델과 제한된 업데이트의 결과는 새 실험 결과로 사용하지 않습니다.

prepare_cache_archive는 전체 tar.xz를 한 볼륨씩 읽어 원래 IFFT→320center crop→magnitude max정규화와 동일한complex64영상을 보관합니다. 모든 파일/슬라이스를 보존하며 다운샘플링하지 않습니다. 원본 전체를 유지하는 대신 자체 임시 원본만 처리 후 정리하여 캐시는 전체 train/val 약32GiB로 예상됩니다. 기존 사용자 원본을 지우지 않습니다. 원본 shape/SHA256/정규화 scale과 전체 스트림 완료 기록을 저장하고12GiB여유 공간을 확보합니다. 정확한 실제 파일 수와 크기는 다운로드 후 inventory로 확인합니다.

각 세션은 기본6시간 후 체크포인트를 저장하고 종료하지만 목표epochs는 항상100입니다. 동일4번/5번 셀을 실행하면 저장된epoch/batch/RNG/optimizer/scaler로 이어집니다. 2번의SESSION_STOP_AT에는 실제 세션 종료 Unix시각을 지정할 수 있으며 자료 준비120초·CDL60초·DDPM480초의 저장 여유를 남깁니다. 제한 없이 재개하려면None으로 둡니다. 한 볼륨 저장이나 optimizer 호출·체크포인트 쓰기는 중간에 안전하게 끊을 수 없으므로 저장 여유가 필요합니다. 이 세션 제한은 체크포인트의 학습 설정과100epochs 목표를 바꾸지 않습니다.

사용자의 Drive 데이터 보관 승인에 따라 USE_GOOGLE_DRIVE/USE_DRIVE_DATA_CACHE=True에서는 MyDrive/SSDM320_full_run/data/train 및 data/val에 전체320complex64 캐시를 보관합니다. 변환 전 임시 원본은/content/ssdm_native_tmp에 두고 자체 임시 파일만 정리합니다. 런타임 종료 후에도 완성된 Drive 파일과 manifest를 재사용하며, 중간에 끊긴 tar.xz 스트림은 재개할 때 압축된 앞부분을 다시 읽을 수 있습니다. 전체 압축 스트림 EOF와 모든 볼륨 검증을 끝내기 전에는 전체 준비 완료로 표시하지 않습니다. Drive 연동은 사용자가 승인하고 인증을 완료한 경우 사용하세요. 무료T4의 런타임/할당 제한은 유지됩니다. 공개 저장소·노트북 사본에는 개인 NYU 다운로드 링크를 포함하지 않습니다.

## 출처와 라이선스

- SSDM: https://proceedings.mlr.press/v315/deng26a.html
- DDS 공식 코드, 고정 commit509b140ee8ba76772ab7d98929270033d4306f2f: https://github.com/hyungjin-chung/DDS/tree/509b140ee8ba76772ab7d98929270033d4306f2f
- DDS 설정: https://github.com/hyungjin-chung/DDS/blob/509b140ee8ba76772ab7d98929270033d4306f2f/configs/vp/fastmri_knee_320_complex.yml
- imGeLU 수식 참고: https://github.com/eejyang/EPCSCNet/blob/main/core/EPCSCNet.py
- ReSample 수식 비교: https://github.com/soominkwon/resample/blob/main/ldm/models/diffusion/ddim.py
- vendor/dds_guided_diffusion의 원본 MIT LICENSE와 PROVENANCE.md를 보존했습니다.
