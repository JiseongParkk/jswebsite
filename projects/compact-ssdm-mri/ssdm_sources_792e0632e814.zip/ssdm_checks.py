"""Numerical correctness checks for the actual SSDM reconstruction modules.

These checks establish tensor/gradient/measurement behavior, not image quality.
The dictionary test uses full 320x320 images and the real 12-block dictionary.
The attention test exercises the production 1024-channel attention in isolation
on a small feature grid; it does not build or train a smaller replacement U-Net.
"""

import importlib.util
from pathlib import Path
import math

import torch

from ssdm_cdl import (
    CoupledDictionary, CDLLossWeights, coupled_dictionary_loss,
    implicit_gelu, complex_to_ri, ri_to_complex, fft2c, ifft2c,
)
from ssdm_backbone import CrossBatchAttention


def _number(value):
    return float(value.detach().cpu())


def dictionary_full_resolution_checks(device="cpu"):
    torch.manual_seed(926)
    device = torch.device(device)
    axis = torch.linspace(-1, 1, 320, device=device)
    gy, gx = torch.meshgrid(axis, axis, indexing="ij")
    magnitude = (
        torch.exp(-((gx / .55).square() + (gy / .8).square()) * 2)
        + .3 * torch.exp(-(((gx - .25) / .12).square() + ((gy + .1) / .2).square()) * 2)
    )
    magnitude /= magnitude.max()
    phase = math.pi * (.7 * gx + .3 * gy)
    image_complex = torch.polar(magnitude, phase).unsqueeze(0)
    image = complex_to_ri(image_complex)
    line_mask = (torch.rand(320, device=device) < .08).float()
    line_mask[154:167] = 1  # Full-size operator test with a retained center.
    mask = line_mask.view(1, 1, 1, 320)
    y = mask[:, 0] * fft2c(image_complex)
    undersampled = complex_to_ri(ifft2c(y))
    dictionary = CoupledDictionary().to(device).train()

    maximum_threshold_error = 0.0
    with torch.no_grad():
        for j, threshold in enumerate(dictionary.thresholds):
            actual = threshold.threshold(image)
            error = (actual - .8 ** j).abs().max()
            maximum_threshold_error = max(maximum_threshold_error, _number(error))
            assert _number(error) < 2e-6, "Appendix threshold initialization changed"

    loss, terms, full, under = coupled_dictionary_loss(
        dictionary, image, undersampled, y, mask, CDLLossWeights()
    )
    assert full.sparse.shape == (1, 8, 320, 320)
    assert full.subspaces.shape == (1, 8, 2, 320, 320)
    assert full.reconstruction.shape == (1, 2, 320, 320)
    assert set(terms) == {
        "reconstruction", "sparsity", "coupling", "global_measurement",
        "unobserved_energy", "orthogonality",
    }
    assert torch.isfinite(loss), "Non-finite full-size CDL loss"
    assert all(torch.isfinite(term) for term in terms.values())
    independent_reconstruction = dictionary.reconstructor(full.sparse)
    component_sum_error = (
        full.reconstruction - independent_reconstruction
    ).abs().max()
    assert _number(component_sum_error) < 2e-6, "R component summation mismatch"
    active_channels = (full.sparse.abs().sum((-2, -1)) > 0).sum()
    assert int(active_channels) == 8, "Initial normalized-input dictionary has dead channels"
    zero_fraction = (full.sparse == 0).float().mean()
    assert 0 < _number(zero_fraction) < 1, "Expected sparse but nontrivial initial codes"
    loss.backward()
    assert all(
        parameter.grad is None or torch.isfinite(parameter.grad).all()
        for parameter in dictionary.parameters()
    ), "Non-finite full-size dictionary gradients"
    gradient_groups = {
        "analysis": [dictionary.w_dec.weight],
        "synthesis": [dictionary.w_conv.weight],
        "reconstructor": [dictionary.reconstructor.weight],
        "threshold_base": [m.base for m in dictionary.thresholds],
        "spatial_threshold_attention": [m.attention[-1].weight for m in dictionary.thresholds],
        "elastic_correction": [m.q2.weight for m in dictionary.elastic],
    }
    gradient_norms = {}
    for name, parameters in gradient_groups.items():
        norm = sum(
            _number(p.grad.norm()) for p in parameters if p.grad is not None
        )
        assert norm > 0, f"Missing gradient through {name}"
        gradient_norms[name] = norm

    fft_error = (ifft2c(fft2c(image_complex)) - image_complex).norm() / image_complex.norm()
    assert _number(fft_error) < 2e-6, "Centered full-size FFT round-trip mismatch"
    # At x=0, imGeLU=0 and its derivative is 1/4, distinct from ordinary GELU.
    activation_input = torch.tensor([0.0], device=device, requires_grad=True)
    activation_value = implicit_gelu(activation_input)
    derivative, = torch.autograd.grad(activation_value.sum(), activation_input)
    assert _number(activation_value.abs().max()) == 0
    assert abs(_number(derivative) - .25) < 2e-6, "imGeLU replaced with a different activation"
    result = {
        "shape": [1, 8, 2, 320, 320],
        "threshold_initialization_max_error": maximum_threshold_error,
        "active_channels": int(active_channels),
        "initial_zero_fraction": _number(zero_fraction),
        "component_sum_max_error": _number(component_sum_error),
        "fft_roundtrip_relative_error": _number(fft_error),
        "loss_terms": {name: _number(term) for name, term in terms.items()},
        "gradient_norms": gradient_norms,
    }
    del dictionary, full, under, loss
    return result


def cross_batch_attention_isolation_checks(device="cpu"):
    torch.manual_seed(927)
    # This is the production deepest width; only the isolated feature grid is small.
    attention = CrossBatchAttention(channels=1024, subspaces=8, heads=16).to(device).eval()
    with torch.no_grad():
        # Production initializes this projection to zero. Activate the test
        # instance so group-isolation checks cannot pass as a trivial identity.
        attention.proj.weight.copy_(torch.eye(1024, device=device))
        attention.proj.bias.zero_()
    features = torch.randn(16, 1024, 3, 4, device=device, requires_grad=True)
    result = attention(features)
    perturbed_other_image = features.detach().clone()
    perturbed_other_image[8:] += .8 * torch.randn_like(perturbed_other_image[8:])
    changed = attention(perturbed_other_image)
    isolation_error = (result[:8].detach() - changed[:8]).abs().max()
    assert _number(isolation_error) < 2e-6, "CBA leaks information between unrelated images"

    gradient, = torch.autograd.grad(result[1].square().mean(), features)
    within_group_gradient = gradient[0].norm()
    unrelated_group_gradient = gradient[8:].abs().max()
    assert _number(within_group_gradient) > 0, "CBA does not couple distinct components"
    assert _number(unrelated_group_gradient) == 0, "CBA gradient crosses image groups"

    perturbed_one_location = features.detach().clone()
    perturbed_one_location[0, :, 0, 0] += .8 * torch.randn(1024, device=device)
    changed_location = attention(perturbed_one_location)
    unaffected_location_error = (
        result[1, :, 1, 1].detach() - changed_location[1, :, 1, 1]
    ).abs().max()
    assert _number(unaffected_location_error) < 2e-6, "CBA mixes spatial locations unexpectedly"
    answer = {
        "feature_channels": 1024,
        "same_image_component_cross_gradient_norm": _number(within_group_gradient),
        "other_image_output_max_error": _number(isolation_error),
        "other_image_gradient_max": _number(unrelated_group_gradient),
        "other_location_output_max_error": _number(unaffected_location_error),
    }
    del attention, features, result
    return answer


def backbone_structure_checks(model):
    """Inspect the existing full model; do not allocate a second large U-Net."""
    assert model.cfg.image_size == 320
    assert model.cfg.subspaces == 8
    assert model.cfg.model_channels == 256
    assert model.encoder_cross_attention.channels == 1024
    assert model.middle_cross_attention.channels == 1024
    assert model.out[-1].out_channels == 2
    report = model.architecture_report()
    assert report["parameters"] > 350_000_000, "Unexpected reduced-width diffusion model"
    return report


def run_numerical_checks(device="cpu", include_sampling=True):
    report = {
        "dictionary": dictionary_full_resolution_checks(device),
        "cross_batch_attention": cross_batch_attention_isolation_checks(device),
    }
    if include_sampling:
        from ssdm_sampling import sampling_smoke_tests
        report["sampling"] = sampling_smoke_tests(device)
    # Import only once present; root may still be writing pipeline integration.
    if Path(__file__).with_name("ssdm_pipeline.py").exists():
        report["pipeline_module_present"] = importlib.util.find_spec("ssdm_pipeline") is not None
    print("Full-resolution dictionary and production-width attention checks passed.")
    print("These numerical checks do not establish reconstruction performance.")
    return report
