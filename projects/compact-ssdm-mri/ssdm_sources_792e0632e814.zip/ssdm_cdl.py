"""SSDM coupled dictionary stage, based on Eqs. (2)-(6) and (13).

The paper specifies 12 LISTA blocks, 8 sparse channels, 2 real/imaginary
input channels, imGeLU elastic corrections, and pixel-adaptive thresholds.
Kernel size, threshold attention topology, z_0, padding, optimizer and numeric
loss weights are not supplied. Those choices are exposed and documented here.

imGeLU follows the cited Yang et al. authors' implementation:
https://github.com/eejyang/EPCSCNet/blob/main/core/EPCSCNet.py
This file implements the equations; it is not the SSDM authors' released code.
"""

from dataclasses import dataclass
from typing import Dict, Optional
import math

import torch
import torch.nn as nn
import torch.nn.functional as F


def ri_to_complex(image: torch.Tensor) -> torch.Tensor:
    """Convert (...,2,H,W) real/imaginary channels without a magnitude step."""
    if image.shape[-3] != 2:
        raise ValueError("Expected (...,2,H,W) real/imaginary channels")
    return torch.complex(image.select(-3, 0).float(), image.select(-3, 1).float())


def complex_to_ri(image: torch.Tensor) -> torch.Tensor:
    return torch.stack((image.real, image.imag), dim=-3)


def fft2c(image: torch.Tensor) -> torch.Tensor:
    return torch.fft.fftshift(
        torch.fft.fft2(torch.fft.ifftshift(image, dim=(-2, -1)), norm="ortho"),
        dim=(-2, -1),
    )


def ifft2c(kspace: torch.Tensor) -> torch.Tensor:
    return torch.fft.fftshift(
        torch.fft.ifft2(torch.fft.ifftshift(kspace, dim=(-2, -1)), norm="ortho"),
        dim=(-2, -1),
    )


def implicit_gelu(x: torch.Tensor) -> torch.Tensor:
    """Exact imGeLU from the referenced EPCSCNet, rather than ordinary GELU."""
    normal_cdf = 0.5 * (1.0 + torch.erf(x / math.sqrt(2.0)))
    normal_pdf = torch.exp(-0.5 * x.square()) / math.sqrt(2.0 * math.pi)
    return (normal_cdf + x * normal_pdf) * x * normal_cdf


class ElasticCorrection(nn.Module):
    def __init__(self, channels: int):
        super().__init__()
        self.q1 = nn.Conv2d(channels, channels, 1, bias=True)
        self.q2 = nn.Conv2d(channels, channels, 1, bias=True)
        # Referenced authors initialize Q1 with small row-normalized filters
        # and Q2 with their transpose. Zero biases are our MRI initialization.
        with torch.no_grad():
            weight = torch.randn_like(self.q1.weight)
            weight = 0.01 * weight / weight.square().sum(1, keepdim=True).sqrt().clamp_min(1e-8)
            self.q1.weight.copy_(weight)
            self.q2.weight.copy_(weight.transpose(0, 1))
            self.q1.bias.zero_()
            self.q2.bias.zero_()

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        return self.q2(implicit_gelu(self.q1(z)))


class SpatialAdaptiveThreshold(nn.Module):
    """A documented threshold-attention choice where the paper is unspecified.

rho_j(x) = softplus(base_j) * 2 sigmoid(Conv1(GELU(Conv3(x)))).
The last attention layer starts at zero, so the initial threshold is exactly
1 * 0.8**j at every pixel and channel, as required by Appendix A.1.
"""

    def __init__(self, channels: int, initial_threshold: float, hidden: int = 16):
        super().__init__()
        inverse_softplus = math.log(math.expm1(initial_threshold))
        self.base = nn.Parameter(torch.full((1, channels, 1, 1), inverse_softplus))
        self.attention = nn.Sequential(
            nn.Conv2d(2, hidden, 3, padding=1),
            nn.GELU(),
            nn.Conv2d(hidden, channels, 1),
        )
        nn.init.zeros_(self.attention[-1].weight)
        nn.init.zeros_(self.attention[-1].bias)

    def threshold(self, image: torch.Tensor) -> torch.Tensor:
        return F.softplus(self.base) * (2.0 * torch.sigmoid(self.attention(image)))

    def forward(self, value: torch.Tensor, image: torch.Tensor) -> torch.Tensor:
        rho = self.threshold(image)
        return value.sign() * F.relu(value.abs() - rho)


@dataclass
class DictionaryOutput:
    sparse: torch.Tensor          # B,L,H,W
    subspaces: torch.Tensor       # B,L,2,H,W
    reconstruction: torch.Tensor  # B,2,H,W


class CoupledDictionary(nn.Module):
    """Equation (13), with independent learned analysis, synthesis and R.

Defaults follow the paper's explicit dimensions. Kernel=3, same zero padding,
z_0=0, and stable biorthogonal frame initialization are implementation choices.
The analysis initialization has gain 2 so rho_0=1 does not force every block
to be inactive on normalized MRI. Threshold values are not silently reduced.
"""

    def __init__(self, channels: int = 8, blocks: int = 12, kernel_size: int = 3):
        super().__init__()
        if kernel_size % 2 != 1:
            raise ValueError("An odd kernel size is required for same-size components")
        self.channels = channels
        self.blocks = blocks
        self.padding = kernel_size // 2
        self.w_dec = nn.Conv2d(2, channels, kernel_size, padding=self.padding, bias=False)
        self.w_conv = nn.ConvTranspose2d(channels, 2, kernel_size, padding=self.padding, bias=False)
        self.reconstructor = nn.ConvTranspose2d(channels, 2, kernel_size, padding=self.padding, bias=False)
        self.elastic = nn.ModuleList([ElasticCorrection(channels) for _ in range(blocks)])
        self.thresholds = nn.ModuleList([
            SpatialAdaptiveThreshold(channels, 0.8 ** j) for j in range(blocks)
        ])
        self._initialize_frame(kernel_size)

    @torch.no_grad()
    def _initialize_frame(self, kernel_size: int):
        # Evenly spaced 2D directions satisfy sum_i v_i v_i^T=(L/2)I.
        # Thus W_conv W_dec = I before the small symmetry-breaking perturbation.
        angles = torch.arange(self.channels, dtype=self.w_dec.weight.dtype) * (2 * math.pi / self.channels)
        directions = torch.stack((angles.cos(), angles.sin()), dim=1)
        analysis = torch.zeros_like(self.w_dec.weight)
        synthesis = torch.zeros_like(self.w_conv.weight)
        center = kernel_size // 2
        analysis[:, :, center, center] = 2.0 * directions
        synthesis[:, :, center, center] = directions / self.channels
        self.w_dec.weight.copy_(analysis + 1e-3 * torch.randn_like(analysis))
        self.w_conv.weight.copy_(synthesis + 1e-4 * torch.randn_like(synthesis))
        self.reconstructor.weight.copy_(synthesis + 1e-4 * torch.randn_like(synthesis))

    def decompose(self, image: torch.Tensor) -> DictionaryOutput:
        if image.ndim != 4 or image.shape[1] != 2:
            raise ValueError("CDL expects B,2,H,W; magnitude-only input loses complex phase")
        z = image.new_zeros((image.shape[0], self.channels, *image.shape[-2:]))
        w_dec_x = self.w_dec(image)
        for elastic, threshold in zip(self.elastic, self.thresholds):
            candidate = z + w_dec_x - self.w_dec(self.w_conv(z)) + elastic(z)
            z = threshold(candidate, image)
        # Grouped transpose-convolution applies exactly the i-th R kernel to
        # the i-th sparse channel, without adding per-subspace biases.
        pieces = F.conv_transpose2d(
            z, self.reconstructor.weight, padding=self.padding, groups=self.channels
        )
        pieces = pieces.reshape(image.shape[0], self.channels, 2, *image.shape[-2:])
        return DictionaryOutput(z, pieces, pieces.sum(dim=1))

    def forward(self, image: torch.Tensor) -> DictionaryOutput:
        return self.decompose(image)


@dataclass
class CDLLossWeights:
    """Numerical weights are disclosed choices, not values reported in SSDM.

Each squared norm is divided by its number of complex pixels; sparse L1 is
averaged over coefficients. Report every term so weights can be calibrated
without looking at the held-out reconstruction test subjects.
"""
    reconstruction: float = 1.0
    sparsity: float = 1e-3
    coupling: float = 1.0
    global_measurement: float = 1.0
    unobserved_energy: float = 1e-3  # lambda_u; paper gives no numeric value
    orthogonality: float = 1e-2


def _squared_complex_mean(image: torch.Tensor) -> torch.Tensor:
    return ri_to_complex(image).abs().square().mean()


def cosine_orthogonality(subspaces: torch.Tensor) -> torch.Tensor:
    """Squared off-diagonal cosine in the real/imaginary vector embedding.

The paper supplies the intent, but no formula for L_perp or its reduction.
This penalty encourages decorrelation; it does not enforce exact orthogonality.
"""
    flat = F.normalize(subspaces.flatten(start_dim=2), dim=-1, eps=1e-8)
    gram = flat @ flat.transpose(1, 2)
    count = subspaces.shape[1]
    off_diagonal = ~torch.eye(count, dtype=torch.bool, device=subspaces.device)
    return gram[:, off_diagonal].square().mean()


def coupled_dictionary_loss(
    model: CoupledDictionary,
    fully_sampled: torch.Tensor,
    undersampled: torch.Tensor,
    measured_kspace: torch.Tensor,
    sampling_mask: torch.Tensor,
    weights: Optional[CDLLossWeights] = None,
) -> tuple[torch.Tensor, Dict[str, torch.Tensor], DictionaryOutput, DictionaryOutput]:
    """Coupled full/undersampled CDL objective, Eqs. (3)-(6).

Measured input is a zero-padded complex B,H,W array. Mask is H,W, B,H,W,
or B,1,H,W. Under/full images must share the same normalization and mask.
Eq. (6)'s unobserved energy penalty applies to undersampled components; the
paper does not explicitly label that symbol. Applying it to full-reference
components would suppress the very missing signal that stage 2 must learn.
Self-reconstruction is averaged over both full and undersampled inputs, a
declared interpretation of Eq. (3)'s otherwise unspecified input distribution.
"""
    weights = weights or CDLLossWeights()
    full = model(fully_sampled)
    under = model(undersampled)
    mask = sampling_mask.to(device=fully_sampled.device, dtype=torch.float32)
    if mask.ndim == 2:
        mask = mask[None, None]
    elif mask.ndim == 3:
        mask = mask[:, None]
    if mask.ndim != 4 or mask.shape[1] != 1:
        raise ValueError("Sampling mask must broadcast as B,1,H,W")
    full_k = fft2c(ri_to_complex(full.subspaces))
    under_k = fft2c(ri_to_complex(under.subspaces))
    measured = measured_kspace.to(under_k.dtype)
    if measured.ndim == 4 and measured.shape[1] == 1:
        measured = measured[:, 0]
    terms = {
        "reconstruction": 0.5 * (
            _squared_complex_mean(full.reconstruction - fully_sampled)
            + _squared_complex_mean(under.reconstruction - undersampled)
        ),
        "sparsity": 0.5 * (full.sparse.abs().mean() + under.sparse.abs().mean()),
        "coupling": (mask * (under_k - full_k)).abs().square().mean(),
        "global_measurement": (
            mask[:, 0] * under_k.sum(1) - measured
        ).abs().square().mean(),
        "unobserved_energy": ((1 - mask) * under_k).abs().square().mean(),
        "orthogonality": 0.5 * (
            cosine_orthogonality(full.subspaces) + cosine_orthogonality(under.subspaces)
        ),
    }
    loss = sum(getattr(weights, name) * value for name, value in terms.items())
    return loss, terms, full, under
