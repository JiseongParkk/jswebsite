"""Capacity check for two real optimizer steps of the unchanged full SSDM model.

This uses an untrained, frozen dictionary and discards all model weights. It is
a functional memory test, never a completed training run or quality evaluation.
"""

from pathlib import Path
import contextlib
import gc
import json
import time

import torch
from torch import nn

from ssdm_backbone import SSDMUNet
from ssdm_cdl import CoupledDictionary
from ssdm_experiment import FastMRISlices, autocast_context, json_write


def _host_memory():
    """Current and peak process RSS, plus available Linux system memory."""
    result = {}
    try:
        values = {}
        for line in Path("/proc/self/status").read_text().splitlines():
            key, _, value = line.partition(":")
            if key in ("VmRSS", "VmHWM"):
                values[key] = int(value.split()[0]) * 1024
        result["rss_GiB"] = round(values.get("VmRSS", 0) / 2**30, 3)
        result["process_peak_rss_GiB"] = round(values.get("VmHWM", 0) / 2**30, 3)
        for line in Path("/proc/meminfo").read_text().splitlines():
            if line.startswith("MemAvailable:"):
                result["system_available_GiB"] = round(int(line.split()[1]) * 1024 / 2**30, 3)
                break
    except (OSError, ValueError):
        try:
            import psutil
            result["rss_GiB"] = round(psutil.Process().memory_info().rss / 2**30, 3)
            result["system_available_GiB"] = round(psutil.virtual_memory().available / 2**30, 3)
        except ImportError:
            result["rss_unavailable"] = True
    return result


def _memory_snapshot():
    result = _host_memory()
    if torch.cuda.is_available():
        result.update(
            cuda_allocated_GiB=round(torch.cuda.memory_allocated() / 2**30, 3),
            cuda_reserved_GiB=round(torch.cuda.memory_reserved() / 2**30, 3),
            cuda_step_peak_allocated_GiB=round(torch.cuda.max_memory_allocated() / 2**30, 3),
            cuda_step_peak_reserved_GiB=round(torch.cuda.max_memory_reserved() / 2**30, 3),
        )
    return result


def _optimizer_report(optimizer):
    steps, moment_bytes = [], 0
    for state in optimizer.state.values():
        if "step" in state:
            steps.append(int(state["step"].item()))
        for name in ("exp_avg", "exp_avg_sq"):
            if name in state:
                tensor = state[name]
                moment_bytes += tensor.numel() * tensor.element_size()
    return {
        "optimizer_state_parameters": len(steps),
        "optimizer_step_min": min(steps) if steps else 0,
        "optimizer_step_max": max(steps) if steps else 0,
        "adam_moment_GiB": round(moment_bytes / 2**30, 3),
    }


def memory_preflight(cfg, updates=2, pin_memory=True, dataset_dir=None):
    """Perform >=2 successful full320 optimizer steps, then discard all weights.

    `pin_memory=True` matches train_diffusion's current CPU activation offload.
    `False` is an explicit low-RSS alternative with pageable CPU storage; it
    changes data-transfer speed, not architecture or loss. A training capacity
    claim requires training to use the same offload strategy as this test.

    dataset_dir defaults to cfg.train_dir. A validation image may be supplied
    explicitly for this disposable functional test; it never trains saved weights
    or produces reconstruction quality metrics. No fallback or model shrinking
    occurs if CUDA or host memory is insufficient.
    """
    if not torch.cuda.is_available():
        raise RuntimeError("The full-model memory preflight requires a CUDA runtime")
    if int(updates) != updates or updates < 2:
        raise ValueError("At least two successful optimizer steps are required")
    if cfg.image_size != 320 or cfg.batch_images != 1:
        raise ValueError("This preflight verifies exactly full320 with one image and eight components")
    if cfg.precision not in ("fp16", "fp32"):
        raise ValueError("Preflight supports the experiment's fp16 or fp32 precision")
    directory = Path(dataset_dir or cfg.train_dir)
    used_validation = directory.resolve() == Path(cfg.val_dir).resolve()
    report = {
        "functional_capacity_test_only": True,
        "completed_training": False,
        "training_goal_advanced": False,
        "image_quality_evaluated": False,
        "weights_saved": False,
        "weights_discarded": False,
        "untrained_frozen_dictionary": True,
        "validation_image_used_for_disposable_capacity_test": used_validation,
        "training_test_dataset_used": directory.resolve() == Path(cfg.train_dir).resolve(),
        "required_successful_updates": int(updates),
        "actual_successful_updates": 0,
        "image_size": 320,
        "subspaces": 8,
        "batch_images": 1,
        "precision": cfg.precision,
        "activation_cpu_offload": bool(cfg.activation_cpu_offload),
        "offload_pin_memory": bool(pin_memory),
        "checkpoints_saved": False,
        "steps": [],
        "skipped_updates": 0,
        "initial_memory": _memory_snapshot(),
        "gpu_name": torch.cuda.get_device_name(),
        "gpu_total_GiB": round(torch.cuda.get_device_properties(0).total_memory / 2**30, 3),
    }
    rng_cpu, rng_cuda = torch.get_rng_state(), torch.cuda.get_rng_state_all()
    model = optimizer = cdl = scaler = dataset = None
    x = clean = noise = noisy = eps = x0 = noise_loss = rec_loss = loss = a = t = ac = grad_norm = None
    last_weight = None
    failed = False
    overall_start = time.monotonic()
    try:
        torch.manual_seed(cfg.seed)
        torch.cuda.manual_seed_all(cfg.seed)
        dataset = FastMRISlices(directory, training=True, size=320)
        image, filename, slice_id = dataset[0]
        x = image[None].to("cuda")
        report["source_filename"] = filename
        report["source_slice"] = int(slice_id)
        del image
        print("Full320 memory preflight; untrained dictionary, disposable weights; source:",
              filename, "slice", slice_id, "validation image:", used_validation, flush=True)

        cdl = CoupledDictionary().to("cuda").eval().requires_grad_(False)
        with torch.no_grad():
            clean = cdl(x).subspaces.detach()
        if clean.shape != (1, 8, 2, 320, 320):
            raise RuntimeError("Dictionary changed the required component shape")
        model = SSDMUNet().to("cuda").train()
        report["architecture"] = model.architecture_report()
        if report["architecture"]["parameters"] != 369_824_514:
            raise RuntimeError("The full369.8M backbone architecture changed")
        optimizer = torch.optim.AdamW(model.parameters(), lr=cfg.diffusion_lr,
                                      weight_decay=0, foreach=False)
        scaler = torch.amp.GradScaler("cuda", enabled=cfg.precision == "fp16", init_scale=1024)
        ac = (1-torch.linspace(cfg.beta_start, cfg.beta_end, cfg.timesteps, device="cuda")).cumprod(0)
        last_weight = model.out[-1].weight.detach().cpu().clone()
        consecutive_skips = 0
        attempts = 0
        while report["actual_successful_updates"] < updates:
            attempts += 1
            optimizer.zero_grad(set_to_none=True)
            torch.cuda.synchronize()
            torch.cuda.reset_peak_memory_stats()
            started = time.monotonic()
            t = torch.randint(cfg.timesteps, (1,), device="cuda")
            a = ac[t].reshape(-1, 1, 1, 1, 1)
            noise = torch.randn_like(clean)
            noisy = a.sqrt()*clean + (1-a).sqrt()*noise
            offload = (torch.autograd.graph.save_on_cpu(pin_memory=pin_memory)
                       if cfg.activation_cpu_offload else contextlib.nullcontext())
            with offload:
                with autocast_context(torch.device("cuda"), cfg.precision):
                    eps = model(noisy, t)
                eps = eps.float()
                noise_loss = (eps-noise).square().mean()
                x0 = (noisy-(1-a).sqrt()*eps)/a.sqrt()
                rec_loss = (x0.sum(1)-x).square().sum(1).mean()
                loss = noise_loss + cfg.reconstruction_weight*rec_loss
            forward_memory = _memory_snapshot()
            if not torch.isfinite(loss):
                raise RuntimeError("Non-finite preflight diffusion loss")
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            grad_norm = nn.utils.clip_grad_norm_(model.parameters(), 1, foreach=False)
            if not scaler.is_enabled() and not torch.isfinite(grad_norm):
                raise RuntimeError("Non-finite preflight gradients; no update performed")
            scale_before = scaler.get_scale()
            scaler.step(optimizer)
            scaler.update()
            torch.cuda.synchronize()
            if scaler.is_enabled() and scaler.get_scale() < scale_before:
                report["skipped_updates"] += 1
                consecutive_skips += 1
                print("Preflight skipped non-finite gradients; no update counted; scale",
                      scaler.get_scale(), flush=True)
                if consecutive_skips >= 8:
                    raise RuntimeError("Eight consecutive preflight updates were skipped")
                # Release the previous graph/output before retrying at a lower scale.
                noise = noisy = eps = x0 = noise_loss = rec_loss = loss = a = t = grad_norm = None
                continue
            if not torch.isfinite(grad_norm):
                raise RuntimeError("Non-finite gradient norm after an apparently successful update")
            consecutive_skips = 0
            current_weight = model.out[-1].weight.detach().cpu()
            delta = float((current_weight-last_weight).abs().max())
            if not torch.isfinite(current_weight).all() or delta <= 0:
                raise RuntimeError("Optimizer step did not produce a finite output-weight change")
            last_weight = current_weight.clone()
            del current_weight
            report["actual_successful_updates"] += 1
            step = {
                "successful_update": report["actual_successful_updates"],
                "attempt": attempts,
                "noise_loss": float(noise_loss.detach()),
                "reconstruction_loss": float(rec_loss.detach()),
                "total_loss": float(loss.detach()),
                "gradient_norm": float(grad_norm),
                "output_weight_max_change": delta,
                "grad_scaler_scale": scaler.get_scale(),
                "seconds": round(time.monotonic()-started, 2),
                "forward_memory": forward_memory,
                "after_optimizer_memory": _memory_snapshot(),
                "optimizer": _optimizer_report(optimizer),
            }
            if step["optimizer"]["optimizer_step_min"] != report["actual_successful_updates"]:
                raise RuntimeError("AdamW state counter does not match actual optimizer updates")
            report["steps"].append(step)
            print(json.dumps(step, indent=2), flush=True)
            noise = noisy = eps = x0 = noise_loss = rec_loss = loss = a = t = grad_norm = None
        report["passed"] = True
    except Exception as exc:
        failed = True
        report["passed"] = False
        report["error_type"] = type(exc).__name__
        report["error"] = str(exc)[:1500]
        report["failure_memory"] = _memory_snapshot()
    finally:
        # Do not return models, retain optimizer state, or write a weights file.
        if optimizer is not None:
            optimizer.zero_grad(set_to_none=True)
        model = optimizer = cdl = scaler = dataset = None
        x = clean = noise = noisy = eps = x0 = noise_loss = rec_loss = loss = a = t = ac = grad_norm = None
        last_weight = None
        gc.collect()
        torch.cuda.empty_cache()
        torch.set_rng_state(rng_cpu)
        torch.cuda.set_rng_state_all(rng_cuda)
        report["weights_discarded"] = True
        report["elapsed_seconds"] = round(time.monotonic()-overall_start, 2)
        report["after_cleanup_memory"] = _memory_snapshot()
        try:
            json_write(Path(cfg.output_dir)/"memory_preflight.json", report)
        except OSError as exc:
            report["report_write_error"] = type(exc).__name__
        print("Full-model disposable memory preflight passed:", report.get("passed", False),
              "actual updates:", report["actual_successful_updates"],
              "weights saved:", False, flush=True)
    if failed:
        raise RuntimeError(
            "Full320/369.8M memory preflight failed after "
            + str(report["actual_successful_updates"]) + " successful updates ("
            + report["error_type"] + "). Training was not started and no model was shrunk. "
            + "See memory_preflight.json for the measured memory and error."
        ) from None
    return report
