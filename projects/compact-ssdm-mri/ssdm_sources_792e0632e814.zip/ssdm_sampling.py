"""SSDM sampler draft: equations 10--12, explicit ambiguity choices.

The paper does not publish gamma, C, eta, CG tolerance, GD iterations/LR.
Algorithm 1 also mixes alpha and alpha_bar, and output t versus t-1.
This draft uses cumulative alpha for Tweedie/DDIM, with a current -> previous
selected timestep convention. All such choices must remain in experiment metadata.

Paper Eq12 has a different variance schedule than the cited ReSample code.
Choose sigma_schedule explicitly instead of claiming a bit-identical reproduction.
model(s_flat, t_flat) takes [B*L,2,H,W], keeping each image's L components adjacent.
"""

from dataclasses import dataclass
import torch


def _require_finite(value, description):
    """Fail at the first invalid numerical stage instead of saving NaN metrics."""
    if not bool(torch.isfinite(value).all()):
        raise FloatingPointError("Non-finite SSDM " + description)


def channels_to_complex(x):
    return torch.view_as_complex(x.movedim(-3, -1).contiguous())


def complex_to_channels(x):
    return torch.view_as_real(x).movedim(-1, -3).contiguous()


def fft2c(x):
    return torch.fft.fftshift(torch.fft.fft2(torch.fft.ifftshift(x, dim=(-2, -1)), norm="ortho"), dim=(-2, -1))


def ifft2c(x):
    return torch.fft.fftshift(torch.fft.ifft2(torch.fft.ifftshift(x, dim=(-2, -1)), norm="ortho"), dim=(-2, -1))


@dataclass
class SamplerConfig:
    # All defaults below are reproduction choices, except paper inference_steps=100.
    inference_steps: int = 100
    ddim_eta: float = 0.0
    gamma: float = 1.0
    resample_every: int = 10
    sigma_schedule: str = "paper_literal"
    cg_steps: int = 12
    cg_rtol: float = 1e-6
    gd_steps: int = 20
    gd_lr: float | None = None
    gd_rtol: float = 1e-6


def subspace_cg(x0_hat, anchors, mask, steps=12, rtol=1e-6):
    """Eq11: solve (I+A* A)s=x0_hat+A*b independently per component.

    x0_hat: [B,L,2,H,W], anchors complex [B,L,H,W].
    mask must broadcast to [B,L,H,W], e.g. [B,1,H,W].
    Stop once every component's residual meets the requested tolerance. This
    changes the number of solver iterations, not Eq11 or its solution.
    """
    _require_finite(x0_hat, "CG clean estimate")
    _require_finite(anchors, "CG anchors")
    def normal(v):
        c = channels_to_complex(v)
        return v + complex_to_channels(ifft2c(mask * fft2c(c)))

    def dot(a, b):
        return (a * b).sum((-3, -2, -1), keepdim=True)

    rhs = x0_hat + complex_to_channels(ifft2c(mask * anchors))
    x = x0_hat.clone()
    r = rhs - normal(x)
    p = r.clone()
    rs = dot(r, r)
    rs0 = rs.clone()
    _require_finite(rs, "CG initial residual norm")
    for _ in range(steps):
        active = rs > rtol**2 * rs0
        if not bool(active.any()):
            break
        ap = normal(p)
        alpha = torch.where(active, rs / dot(p, ap).clamp_min(1e-30), torch.zeros_like(rs))
        x = x + alpha * p
        r = r - alpha * ap
        rs_new = dot(r, r)
        _require_finite(rs_new, "CG residual norm")
        beta = torch.where(active, rs_new / rs.clamp_min(1e-30), torch.zeros_like(rs))
        p = r + beta * p
        rs = rs_new
    _require_finite(x, "CG solution")
    return x


def global_gradient_descent(s0, y, mask, steps=20, lr=None, rtol=1e-6):
    """Eq10, gradient through PyTorch autograd, initialized at Eq11 solution.

    Unit-norm Cartesian FFT makes lr=1/(2L) solve observed sum residual in one
    iteration. The paper specifies gradient descent, but not learning rate or count.
    Stop only when each image's observed residual is <= rtol * ||y||. For zero
    measurements, use that image's initial residual as its relative scale.
    """
    _require_finite(s0, "global-guidance input")
    _require_finite(y, "measurements")
    lr = 1 / (2 * s0.shape[1]) if lr is None else lr
    # mask for single summed image, shape [B,H,W]
    summed_mask = mask[:, 0] if mask.ndim == 4 else mask
    z = s0.detach()
    target_norm = y.abs().square().flatten(1).sum(1).sqrt()
    residual_scale = None
    with torch.enable_grad():
        for _ in range(steps):
            z = z.detach().requires_grad_(True)
            residual = summed_mask * fft2c(channels_to_complex(z.sum(1))) - y
            _require_finite(residual, "global-guidance residual")
            residual_norm = residual.abs().square().flatten(1).sum(1).sqrt()
            if residual_scale is None:
                residual_scale = torch.where(target_norm > 0, target_norm,
                                             residual_norm.detach())
            if bool((residual_norm <= rtol * residual_scale).all()):
                break
            loss = residual.abs().square().sum()
            grad, = torch.autograd.grad(loss, z)
            _require_finite(grad, "global-guidance gradient")
            z = z - lr * grad
    _require_finite(z, "global-guidance solution")
    return z.detach()


def stochastic_resample(s0_guided, s_prev, a_prev, sigma2):
    """Eq12 evaluated at previous selected timestep, same scale as diffusion.

    gamma=0 disables resampling, final a_prev=1 returns the guided clean sample.
    """
    if float(a_prev) >= 1:
        return s0_guided
    if float(sigma2) <= 0:
        return s_prev
    v = 1 - a_prev
    denominator = sigma2 + v
    mean = (sigma2 * a_prev.sqrt() * s0_guided + v * s_prev) / denominator
    variance = sigma2 * v / denominator
    return mean + variance.clamp_min(0).sqrt() * torch.randn_like(mean)


@torch.no_grad()
def sample_ssdm(model, y, mask, anchors, betas, config=None, callback=None, s_initial=None):
    """Only measured y and mask enter reconstruction; no reference image enters.

    anchors are M*F(CDL(zero_filled)) with complex shape [B,L,H,W].
    y complex [B,H,W] has zeros off mask.
    Model training and sampler use unscaled image-domain components in this draft.
    Any fixed train-only component scale must transform y, anchors and guidance too.
    """
    config = SamplerConfig() if config is None else config
    if config.sigma_schedule not in {"paper_literal", "resample_reference"}:
        raise ValueError("Choose documented sigma schedule")
    if config.resample_every < 1:
        raise ValueError("resample_every must be at least 1")
    if config.inference_steps < 1:
        raise ValueError("inference_steps must be at least 1")
    _require_finite(y, "sampling measurements")
    _require_finite(mask, "sampling mask")
    _require_finite(anchors, "sampling anchors")
    _require_finite(betas, "noise schedule")
    if anchors.shape[1] != 8:
        raise ValueError("SSDM paper uses eight image-domain components")
    anchors = mask * anchors
    component_template = complex_to_channels(anchors)
    s = torch.randn_like(component_template) if s_initial is None else s_initial.clone()
    if s.shape != component_template.shape:
        raise ValueError("s_initial must have shape [B,8,2,H,W]")
    _require_finite(s, "initial components")
    alphas = 1 - betas
    ac = alphas.cumprod(0)
    times = torch.linspace(len(betas) - 1, 0, config.inference_steps).round().long().tolist()
    if len(times) != len(set(times)):
        raise ValueError("inference_steps exceeds number of diffusion timesteps")
    last_clean = None
    for k, t in enumerate(times):
        u = times[k + 1] if k + 1 < len(times) else -1
        at = ac[t]
        au = ac[u] if u >= 0 else ac.new_tensor(1.0)
        timesteps = torch.full((s.shape[0] * s.shape[1],), t, device=s.device, dtype=torch.long)
        eps = model(s.flatten(0, 1), timesteps).float().reshape_as(s)
        _require_finite(eps, f"predicted epsilon at timestep {t}")
        x0_hat = (s - (1 - at).sqrt() * eps) / at.sqrt()
        _require_finite(x0_hat, f"Tweedie clean estimate at timestep {t}")
        per_component = subspace_cg(x0_hat, anchors, mask, config.cg_steps, config.cg_rtol)
        # Standard DDIM current t -> previous selected u; eta=0 is deterministic.
        ddim_sigma2 = config.ddim_eta**2 * ((1 - au) / (1 - at)) * (1 - at / au)
        ddim_sigma2 = ddim_sigma2.clamp_min(0)
        s_prev = au.sqrt() * per_component + (1 - au - ddim_sigma2).clamp_min(0).sqrt() * eps
        if config.ddim_eta:
            s_prev = s_prev + ddim_sigma2.sqrt() * torch.randn_like(s_prev)
        _require_finite(s_prev, f"DDIM transition {t} -> {u}")
        resample_now = (k % config.resample_every == 0) or u < 0
        if resample_now:
            clean = global_gradient_descent(per_component, y, mask, config.gd_steps,
                                            config.gd_lr, config.gd_rtol)
            if config.sigma_schedule == "paper_literal":
                # Literally printed sigma formula: single-step alpha, t-1 -> selected u.
                alpha_prev = alphas[u] if u >= 0 else alphas.new_tensor(1.0)
                sigma2 = config.gamma * (1 - alpha_prev) / alphas[t] * (1 - alphas[t]) / alpha_prev
            else:
                # Schedule in the original ReSample authors' code, cumulative alpha.
                sigma2 = config.gamma * ((1 - au) / (1 - at)) * (1 - at / au)
            s = stochastic_resample(clean, s_prev, au, sigma2)
        else:
            clean = per_component
            s = s_prev
        _require_finite(clean, f"guided clean components at timestep {t}")
        _require_finite(s, f"reverse-diffusion components at timestep {u}")
        last_clean = clean
        if callback:
            callback(k + 1, t, u, clean)
    output = last_clean.sum(1)
    _require_finite(output, "final reconstruction")
    return output, last_clean


def sampling_smoke_tests(device="cpu"):
    """Numerical checks; none demonstrate reconstruction quality.

    Covers normal equations/analytic Eq11, global loss reduction/measurement
    consistency, Eq12 Gaussian mean/variance, and finite 100-step tensor plumbing.
    """
    torch.manual_seed(712)
    batch, components, height, width = 2, 8, 16, 16
    xhat = torch.randn(batch, components, 2, height, width, device=device)
    mask = (torch.rand(batch, 1, height, width, device=device) > 0.75).float()
    anchors = mask * fft2c(channels_to_complex(torch.randn_like(xhat)))
    cg = subspace_cg(xhat, anchors, mask)
    analytic = complex_to_channels(ifft2c((fft2c(channels_to_complex(xhat)) + anchors) / (1 + mask)))
    cg_error = (cg - analytic).norm() / analytic.norm()
    normal_residual = cg + complex_to_channels(ifft2c(mask * fft2c(channels_to_complex(cg)))) - xhat - complex_to_channels(ifft2c(anchors))
    cg_residual = normal_residual.norm() / (xhat + complex_to_channels(ifft2c(anchors))).norm()
    assert float(cg_error) < 3e-6, f"CG analytic mismatch: {cg_error}"
    assert float(cg_residual) < 3e-6, f"CG normal residual: {cg_residual}"

    reference = torch.randn(batch, 2, height, width, device=device)
    y = mask[:, 0] * fft2c(channels_to_complex(reference))
    before = (mask[:, 0] * fft2c(channels_to_complex(cg.sum(1))) - y).norm()
    guided = global_gradient_descent(cg, y, mask, steps=20)
    guided_k = fft2c(channels_to_complex(guided.sum(1)))
    observed_residual = mask[:, 0] * guided_k - y
    after = observed_residual.norm()
    dc_error = after / y.norm()
    assert float(after) < float(before) * 1e-4, "Eq10 did not reduce measurement error"
    assert float(dc_error) < 3e-6, f"Global data consistency failure: {dc_error}"
    # Check every image independently; a good batch average must not hide a
    # failed subject. Eq10 should leave unobserved frequencies unchanged.
    subject_dc = (observed_residual.abs().square().flatten(1).sum(1).sqrt()
                  / y.abs().square().flatten(1).sum(1).sqrt())
    assert bool((subject_dc < 3e-6).all()), f"Observed residual by image: {subject_dc}"
    original_k = fft2c(channels_to_complex(cg.sum(1)))
    unobserved_change = ((1 - mask[:, 0]) * (guided_k - original_k)).norm() / original_k.norm()
    assert float(unobserved_change) < 3e-6, "Eq10 changed the unobserved frequencies"

    a = torch.tensor(0.3, device=device)
    sigma2 = torch.tensor(0.4, device=device)
    guided_flat = torch.full((100000,), 1.2, device=device)
    previous_flat = torch.full_like(guided_flat, -0.5)
    samples = stochastic_resample(guided_flat, previous_flat, a, sigma2)
    mean = (sigma2 * a.sqrt() * 1.2 + (1 - a) * -0.5) / (sigma2 + 1 - a)
    variance = sigma2 * (1 - a) / (sigma2 + 1 - a)
    empirical_mean = samples.mean()
    empirical_variance = samples.var(unbiased=False)
    assert abs(float(empirical_mean - mean)) < 0.01, "Eq12 Gaussian mean mismatch"
    assert abs(float(empirical_variance / variance - 1)) < 0.025, "Eq12 Gaussian variance mismatch"
    assert torch.equal(stochastic_resample(guided_flat, previous_flat, a.new_tensor(1.), sigma2), guided_flat)

    def zero_epsilon(x, t):
        return torch.zeros_like(x)

    betas = torch.linspace(1e-4, 0.02, 1000, device=device)
    shape_initial = torch.zeros_like(xhat)
    output, subspaces = sample_ssdm(zero_epsilon, y, mask, anchors, betas,
                                  SamplerConfig(gd_steps=1), s_initial=shape_initial)
    assert output.shape == reference.shape
    assert subspaces.shape == xhat.shape
    assert torch.isfinite(output).all(), "Non-finite 100-step sampling output"
    end_dc = (mask[:, 0] * fft2c(channels_to_complex(output)) - y).norm() / y.norm()
    assert float(end_dc) < 1e-4, f"Final measured k-space error: {end_dc}"

    def invalid_epsilon(x, t):
        return torch.full_like(x, float("nan"))

    try:
        sample_ssdm(invalid_epsilon, y, mask, anchors, betas,
                    SamplerConfig(inference_steps=1), s_initial=shape_initial)
    except FloatingPointError as error:
        assert "predicted epsilon" in str(error), "Invalid values failed at the wrong numerical stage"
    else:
        raise AssertionError("A non-finite model prediction was allowed into reconstruction")
    result = dict(cg_analytic_relative_error=float(cg_error),
                  cg_normal_relative_residual=float(cg_residual),
                  global_dc_relative_error=float(dc_error),
                  max_subject_dc_relative_error=float(subject_dc.max()),
                  unobserved_frequency_relative_change=float(unobserved_change),
                  resample_mean_error=float(empirical_mean - mean),
                  resample_variance_ratio=float(empirical_variance / variance),
                  zero_epsilon_100step_dc=float(end_dc))
    print("Sampler numerical checks passed. These checks do not establish image quality.")
    print(result)
    return result
