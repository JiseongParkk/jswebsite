"""SSDM reconstruction backbone from the public DDS / ADM U-Net.

Source backbone: official DDS commit 509b140ee8ba76772ab7d98929270033d4306f2f,
itself derived from OpenAI guided-diffusion (MIT; license in vendor directory).
SSDM specifies cross-batch attention locations, but does not publish its exact
projection widths or number of heads. The attention below is an explicit
implementation choice, not an assertion that it is the authors' private code.

Defaults retain the public DDS 320x320 MRI backbone size (256 base channels,
one ResBlock, six levels). The output has two epsilon channels to implement
SSDM's stated epsilon-MSE training objective; DDS's variance head is omitted.
No automatic width / image-size downgrade is implemented.
"""

from dataclasses import asdict, dataclass
from typing import Tuple

import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.checkpoint import checkpoint

from vendor.dds_guided_diffusion.unet import UNetModel, TimestepBlock
from vendor.dds_guided_diffusion.nn import timestep_embedding


DDS_COMMIT = "509b140ee8ba76772ab7d98929270033d4306f2f"
DDS_CONFIG_URL = (
    "https://github.com/hyungjin-chung/DDS/blob/" + DDS_COMMIT
    + "/configs/vp/fastmri_knee_320_complex.yml"
)


@dataclass(frozen=True)
class BackboneConfig:
    image_size: int = 320
    subspaces: int = 8
    model_channels: int = 256
    num_res_blocks: int = 1
    channel_mult: Tuple[int, ...] = (1, 1, 2, 2, 4, 4)
    # Public DDS passes "16" -> image_size // 16 = 20; the encoder
    # downsample factors are powers of two, so this does not match a level.
    # Retain the literal public configuration; middle spatial attention remains.
    attention_downsample_factors: Tuple[int, ...] = (20,)
    num_head_channels: int = 64
    cross_attention_heads: int = 16
    dropout: float = 0.0
    use_checkpoint: bool = True


class CrossBatchAttention(nn.Module):
    """Attention across L components at each spatial location, within one image.

    Flat-batch order must be [image0 component0..L-1, image1 component0..L-1,...].
    Every spatial location has L tokens; no spatial pooling and no mixing across
    unrelated images occurs. This is a documented choice where SSDM lacks detail.
    """

    def __init__(self, channels: int, subspaces: int = 8, heads: int = 16):
        super().__init__()
        if channels % heads != 0:
            raise ValueError("Cross-attention channels must divide evenly into heads")
        self.channels, self.subspaces, self.heads = channels, subspaces, heads
        self.norm = nn.LayerNorm(channels)
        self.qkv = nn.Linear(channels, 3 * channels)
        self.proj = nn.Linear(channels, channels)
        # A residual initially starts as the identity, as in ADM attention.
        nn.init.zeros_(self.proj.weight)
        nn.init.zeros_(self.proj.bias)

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        n, c, h, w = features.shape
        if c != self.channels or n % self.subspaces != 0:
            raise ValueError("Expected complete contiguous image/component groups")
        b, l, d = n // self.subspaces, self.subspaces, c // self.heads
        tokens = features.reshape(b, l, c, h, w).permute(0, 3, 4, 1, 2)
        tokens = tokens.reshape(b * h * w, l, c)
        qkv = self.qkv(self.norm(tokens))
        qkv = qkv.reshape(b * h * w, l, 3, self.heads, d)
        q, k, v = qkv.permute(2, 0, 3, 1, 4).unbind(0)
        mixed = F.scaled_dot_product_attention(q, k, v, dropout_p=0.0)
        mixed = mixed.transpose(1, 2).reshape(b * h * w, l, c)
        out = tokens + self.proj(mixed)
        return out.reshape(b, h, w, l, c).permute(0, 3, 4, 1, 2).reshape(n, c, h, w)


class SSDMUNet(UNetModel):
    """Shared ADM U-Net, with the two SSDM cross-subspace attention locations.

    Preferred input is [B,L,2,H,W], with one timestep per image [B]. Output has
    the same grouped shape. Flat [B*L,2,H,W] is also accepted with explicit
    contiguous component groups and [B*L] timesteps.
    """

    def __init__(self, cfg: BackboneConfig = BackboneConfig()):
        if cfg.image_size % (2 ** (len(cfg.channel_mult) - 1)) != 0:
            raise ValueError("Image size must be divisible by the full U-Net stride")
        self.cfg = cfg
        super().__init__(
            image_size=cfg.image_size,
            in_channels=2,
            model_channels=cfg.model_channels,
            out_channels=2,
            num_res_blocks=cfg.num_res_blocks,
            attention_resolutions=cfg.attention_downsample_factors,
            dropout=cfg.dropout,
            channel_mult=cfg.channel_mult,
            conv_resample=True,
            dims=2,
            num_classes=None,
            use_checkpoint=False,  # Modern whole-block checkpointing below.
            use_fp16=False,  # Caller selects torch.autocast; FP32 master weights.
            num_heads=4,
            num_head_channels=cfg.num_head_channels,
            num_heads_upsample=-1,
            use_scale_shift_norm=True,
            resblock_updown=True,
            use_new_attention_order=False,
        )
        deepest = cfg.model_channels * cfg.channel_mult[-1]
        self.encoder_cross_attention = CrossBatchAttention(
            deepest, cfg.subspaces, cfg.cross_attention_heads
        )
        self.middle_cross_attention = CrossBatchAttention(
            deepest, cfg.subspaces, cfg.cross_attention_heads
        )

    def _block(self, block, x, emb=None):
        args = (x,) if emb is None else (x, emb)
        if self.cfg.use_checkpoint and self.training and torch.is_grad_enabled():
            return checkpoint(block, *args, use_reentrant=False)
        return block(*args)

    def forward(self, x: torch.Tensor, timesteps: torch.Tensor) -> torch.Tensor:
        grouped = x.ndim == 5
        if grouped:
            b, l, channels, h, w = x.shape
            if l != self.cfg.subspaces:
                raise ValueError("Wrong number of subspace components")
            x = x.reshape(b * l, channels, h, w)
            if timesteps.shape == (b,):
                timesteps = timesteps.repeat_interleave(l)
            elif timesteps.shape == (b, l):
                timesteps = timesteps.reshape(b * l)
        elif x.ndim == 4:
            if x.shape[0] % self.cfg.subspaces != 0:
                raise ValueError("Flat batch must contain whole subspace groups")
            b, l = x.shape[0] // self.cfg.subspaces, self.cfg.subspaces
            channels, h, w = x.shape[1:]
        else:
            raise ValueError("Expected [B,L,2,H,W] or [B*L,2,H,W]")
        if channels != 2 or (h, w) != (self.cfg.image_size, self.cfg.image_size):
            raise ValueError("Input shape differs from the configured full-resolution model")
        if timesteps.shape != (b * l,):
            raise ValueError("Timesteps must contain one entry per image or component")

        emb = self.time_embed(timestep_embedding(timesteps, self.model_channels))
        skip_features = []
        features = x
        for i, block in enumerate(self.input_blocks):
            features = self._block(block, features, emb)
            if i == len(self.input_blocks) - 1:
                features = self._block(self.encoder_cross_attention, features)
            skip_features.append(features)
        # Keep the public ADM ResBlock -> spatial-attention -> ResBlock middle,
        # and place the new cross-subspace block inside it after spatial attention.
        for i, block in enumerate(self.middle_block):
            features = self._block(block, features, emb if isinstance(block, TimestepBlock) else None)
            if i == 1:
                features = self._block(self.middle_cross_attention, features)
        for block in self.output_blocks:
            features = torch.cat([features, skip_features.pop()], dim=1)
            features = self._block(block, features, emb)
        result = self.out(features)
        return result.reshape(b, l, 2, h, w) if grouped else result

    def architecture_report(self):
        total = sum(p.numel() for p in self.parameters())
        cross = sum(p.numel() for p in self.encoder_cross_attention.parameters())
        cross += sum(p.numel() for p in self.middle_cross_attention.parameters())
        return {
            "config": asdict(self.cfg),
            "parameters": total,
            "cross_attention_parameters": cross,
            "backbone_without_cross_attention_parameters": total - cross,
            "SSDM_paper_reported_parameters": 367_400_000,
            "DDS_paper_reported_parameters": 361_400_000,
            "source_commit": DDS_COMMIT,
            "source_config": DDS_CONFIG_URL,
            "unknown_details": [
                "SSDM exact cross-attention projection width and head count are unpublished",
                "same-spatial-location grouped attention is this implementation's choice",
                "DDS has 4 output channels; SSDM epsilon-MSE uses 2 here",
            ],
        }


def build_diffusion_backbone(cfg=None):
    if cfg is None:
        cfg = BackboneConfig()
    elif isinstance(cfg, dict):
        cfg = BackboneConfig(**cfg)
    return SSDMUNet(cfg)
