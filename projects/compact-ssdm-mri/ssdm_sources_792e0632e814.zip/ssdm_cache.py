"""Lossless storage of the experiment's exact 320x320 complex preprocessing.

This changes storage, not the training set or reconstruction objective. Every
native single-coil slice is transformed by the same PyTorch ifft2c, center crop,
and magnitude-max normalization used by FastMRISlices. There is no image resize,
slice selection, real/imaginary quantization, or magnitude-only conversion.

Use a separate cache directory. User-owned raw HDF5 files are never overwritten
or removed. Only temporary files created by this module are cleaned up.
"""

from pathlib import Path
import hashlib
import json
import os
import shutil
import tarfile
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

import h5py
import numpy as np


CACHE_SCHEMA = "ssdm-native-ifft-crop-absmax-complex64-v1"
CACHE_DATASET = "images_complex64"
PREPROCESSING = "torch complex64 native ifft2c(norm=ortho) -> center crop -> absmax.clamp_min(1e-12) normalization"


class CachePreparationError(RuntimeError):
    pass


def _atomic_json(path, content):
    path = Path(path)
    fd, temporary = tempfile.mkstemp(prefix=".ssdm-manifest-", suffix=".json", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf8") as output:
            json.dump(content, output, indent=2, ensure_ascii=False)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def preprocess_kspace_slice(kspace, image_size=320):
    """Exact FastMRISlices numerical operations; returns image and crop scale."""
    import torch
    from ssdm_cdl import ifft2c

    if image_size != 320:
        raise ValueError("This cache format implements the 320x320 experiment only")
    kspace = np.asarray(kspace).astype(np.complex64)
    if kspace.ndim != 2:
        raise ValueError("Expected one native single-coil k-space slice")
    with torch.no_grad():
        x = ifft2c(torch.from_numpy(kspace))
        h, w = x.shape
        if min(h, w) < image_size:
            raise ValueError("Native image is too small for the 320x320 center crop")
        x = x[(h-image_size)//2:(h+image_size)//2,
              (w-image_size)//2:(w+image_size)//2]
        if not torch.isfinite(x).all():
            raise ValueError("Non-finite complex MRI slice")
        scale = x.abs().amax().clamp_min(1e-12)
        x = x / scale
        return x.numpy().copy(), float(scale)


def read_cache_header(path, image_size=320):
    """Read cache provenance; raises ValueError/OSError for an invalid header."""
    path = Path(path)
    with h5py.File(path, "r") as f:
        if f.attrs.get("ssdm_cache_schema", "") != CACHE_SCHEMA:
            raise ValueError("Unrecognized SSDM cache format: " + path.name)
        if not bool(f.attrs.get("complete_volume", False)):
            raise ValueError("Incomplete cached volume: " + path.name)
        if int(f.attrs.get("image_size", -1)) != image_size or image_size != 320:
            raise ValueError("Cached resolution differs from320: " + path.name)
        if CACHE_DATASET not in f or "normalization_scale" not in f:
            raise ValueError("Missing cached complex images or normalization scales")
        images, scales = f[CACHE_DATASET], f["normalization_scale"]
        native = tuple(int(v) for v in f.attrs["source_kspace_shape"])
        if len(native) != 3 or min(native[1:]) < image_size:
            raise ValueError("Invalid native k-space shape")
        if images.shape != (native[0], image_size, image_size):
            raise ValueError("Cached slice count or resolution changed")
        if images.dtype != np.dtype("complex64") or scales.shape != (native[0],):
            raise ValueError("Cached precision or normalization shape changed")
        if scales.dtype != np.dtype("float32") or native[0] < 1:
            raise ValueError("Invalid normalization precision or slice count")
        name = str(f.attrs["source_filename"])
        if name != path.name or Path(name).name != name or not name.endswith(".h5"):
            raise ValueError("Source filename was not preserved")
        digest = str(f.attrs["source_sha256"])
        if len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
            raise ValueError("Invalid source SHA256 provenance")
        return {
            "filename": name,
            "source_archive_member": str(f.attrs.get("source_archive_member", name)),
            "source_bytes": int(f.attrs["source_bytes"]),
            "source_kspace_shape": native,
            "slices": native[0],
            "image_size": image_size,
            "dtype": "complex64",
            "source_sha256": digest,
            "preprocessing": str(f.attrs["preprocessing"]),
            "cache_bytes": path.stat().st_size,
        }


def validate_cache(path, image_size=320, expected_source_bytes=None, full=True):
    """Validate schema/count/precision and, by default, every saved slice."""
    try:
        info = read_cache_header(path, image_size)
        if expected_source_bytes is not None and info["source_bytes"] != expected_source_bytes:
            return False
        if full:
            with h5py.File(path, "r") as f:
                for i in range(info["slices"]):
                    image = f[CACHE_DATASET][i]
                    scale = float(f["normalization_scale"][i])
                    if not np.isfinite(image).all() or not np.isfinite(scale) or scale <= 0:
                        return False
                    if float(np.abs(image).max()) > 1.00001:
                        return False
        return True
    except (OSError, ValueError, KeyError, TypeError, OverflowError):
        return False


def _recognized_cache(path):
    """Distinguish our cache from raw or other user-owned HDF5 before replacement."""
    try:
        with h5py.File(path, "r") as f:
            return f.attrs.get("ssdm_cache_schema", "") == CACHE_SCHEMA
    except OSError:
        return False


def _reserve(directory, additional_bytes, reserve_gb):
    free = shutil.disk_usage(directory).free
    required = int(reserve_gb * 2**30) + int(additional_bytes)
    if free < required:
        raise CachePreparationError(
            "Insufficient storage for the next native volume and its full320cache; "
            "the requested disk reserve is preserved. Use a larger cache directory."
        )


def cache_one_volume(raw_path, target_path, source_archive_member=None,
                     source_bytes=None, source_sha256=None, reserve_gb=12):
    """Convert all slices of one volume, validate, then atomically install it.

    The source file remains untouched. target_path must preserve its original
    archive filename; only this function's unique temporary cache is cleaned up.
    """
    raw_path, target = Path(raw_path), Path(target_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and not _recognized_cache(target):
        raise CachePreparationError("Existing non-cache HDF5 is preserved: " + target.name)
    source_bytes = raw_path.stat().st_size if source_bytes is None else int(source_bytes)
    if raw_path.stat().st_size != source_bytes:
        raise CachePreparationError("Incomplete native volume: " + target.name)
    if source_sha256 is None:
        sha = hashlib.sha256()
        with raw_path.open("rb") as source:
            while block := source.read(4 * 1024**2):
                sha.update(block)
        source_sha256 = sha.hexdigest()
    fd, temporary = tempfile.mkstemp(prefix=".ssdm-cache-", suffix=".part", dir=target.parent)
    os.close(fd)
    try:
        with h5py.File(raw_path, "r") as source:
            if "kspace" not in source or "reconstruction_esc" not in source or "mask" in source:
                raise CachePreparationError("Expected fully sampled single-coil train/val: " + target.name)
            kspace = source["kspace"]
            if (kspace.ndim != 3 or kspace.dtype.kind != "c"
                    or kspace.shape[0] < 1 or min(kspace.shape[1:]) < 320):
                raise CachePreparationError("Invalid native single-coil k-space: " + target.name)
            count = kspace.shape[0]
            _reserve(target.parent, count * 320 * 320 * 8 + 16 * 1024**2, reserve_gb)
            with h5py.File(temporary, "w") as output:
                output.attrs["ssdm_cache_schema"] = CACHE_SCHEMA
                output.attrs["complete_volume"] = False
                output.attrs["source_filename"] = target.name
                output.attrs["source_archive_member"] = source_archive_member or target.name
                output.attrs["source_bytes"] = source_bytes
                output.attrs["source_sha256"] = source_sha256
                output.attrs["source_kspace_shape"] = np.asarray(kspace.shape, dtype=np.int64)
                output.attrs["source_hdf5_keys"] = json.dumps(sorted(source.keys()))
                output.attrs["image_size"] = 320
                output.attrs["preprocessing"] = PREPROCESSING
                output.attrs["fft_normalization"] = "ortho"
                output.attrs["slice_selection"] = "all native slices in original order"
                images = output.create_dataset(
                    CACHE_DATASET, shape=(count, 320, 320), dtype=np.complex64,
                    chunks=(1, 320, 320), compression="lzf", shuffle=True, fletcher32=True,
                )
                scales = output.create_dataset("normalization_scale", shape=(count,), dtype=np.float32)
                for i in range(count):
                    image, scale = preprocess_kspace_slice(kspace[i])
                    if image.shape != (320, 320) or image.dtype != np.dtype("complex64"):
                        raise CachePreparationError("Preprocessing changed precision or resolution")
                    images[i], scales[i] = image, scale
                output.attrs["complete_volume"] = True
                output.flush()
        # Temporary basename is different, so validate all numeric data here;
        # the installed-file validator additionally verifies source filename.
        with h5py.File(temporary, "r") as checked:
            for i in range(count):
                image = checked[CACHE_DATASET][i]
                scale = float(checked["normalization_scale"][i])
                if not np.isfinite(image).all() or not np.isfinite(scale) or scale <= 0:
                    raise CachePreparationError("Cached slice failed all-slice validation")
                if float(np.abs(image).max()) > 1.00001:
                    raise CachePreparationError("Cached slice normalization changed")
        os.replace(temporary, target)
        return read_cache_header(target)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _manifest(directory, names, complete, new_volumes=0, infos=None):
    infos = infos or {}
    result = {
        "complete_archive": bool(complete),
        "cache_schema": CACHE_SCHEMA,
        "cache_dataset": CACHE_DATASET,
        "archive_files": list(names),
        "present_volumes": sum((Path(directory) / n).exists() for n in names),
        "total_slices": sum(int(v["slices"]) for v in infos.values()),
        "new_volumes": new_volumes,
        "image_size": 320,
        "dtype": "complex64",
        "slice_selection": "all native slices in original order",
        "preprocessing": PREPROCESSING,
        "volumes": infos,
    }
    _atomic_json(Path(directory) / "download_manifest.json", result)
    return result


def prepare_cache_archive(url, directory, reserve_gb=12, stop_at=None, native_directory=None):
    """Stream the entire official NYU tar.xz and retain all preprocessed slices.

    A partial run resumes by skipping valid cache volumes, but still consumes the
    archive through EOF before declaring completion. Neither compressed archives
    nor full raw splits are retained. Signed URLs are never printed or persisted.
    stop_at is an optional Unix timestamp. At that time preparation returns at
    a volume boundary with an incomplete manifest and retains every cache file.
    native_directory optionally keeps temporary raw volumes on local scratch
    storage while the completed complex cache remains in directory.
    """
    if stop_at is not None:
        stop_at = float(stop_at)
        if not np.isfinite(stop_at):
            raise ValueError("stop_at must be a finite Unix timestamp")
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    native_directory = directory if native_directory is None else Path(native_directory)
    native_directory.mkdir(parents=True, exist_ok=True)
    report = directory / "download_manifest.json"
    old = {}
    names, infos, new_volumes = [], {}, 0

    def deadline_reached():
        return stop_at is not None and time.time() >= stop_at

    def stop_preparation():
        # While replaying a partial stream, do not erase records for valid
        # volumes retained from an earlier session but not encountered yet.
        previous_names = old.get("archive_files", []) if old.get("cache_schema") == CACHE_SCHEMA else []
        previous_infos = old.get("volumes", {}) if old.get("cache_schema") == CACHE_SCHEMA else {}
        retained_names = list(dict.fromkeys([*previous_names, *names]))
        retained_infos = {**previous_infos, **infos}
        result = _manifest(directory, retained_names, False, new_volumes, retained_infos)
        print("Cache preparation stopped at the deadline; full split remains incomplete:",
              directory.name, "retained volumes:", result["present_volumes"], flush=True)
        return result

    if report.exists():
        old = json.loads(report.read_text(encoding="utf8"))
    if deadline_reached():
        return stop_preparation()
    if old:
        old_names = old.get("archive_files", [])
        if (old.get("complete_archive") and old.get("cache_schema") == CACHE_SCHEMA
                and old_names and len(old_names) == len(set(old_names))):
            for name in old_names:
                if deadline_reached():
                    return stop_preparation()
                if not validate_cache(directory / name):
                    break
            else:
                if deadline_reached():
                    return stop_preparation()
                print("Full320cache already complete:", directory.name, len(old_names), "volumes", flush=True)
                return old
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != "https" or parsed.netloc != "fastmri-dataset.s3.amazonaws.com":
        raise ValueError("Supply this split's official NYU fastMRI download URL")
    _manifest(directory, names, False)
    print("Streaming entire NYU split into exact320complex64 cache:", directory.name, flush=True)
    try:
        with urllib.request.urlopen(url, timeout=120) as response:
            with tarfile.open(fileobj=response, mode="r|xz") as archive:
                members = iter(archive)
                while True:
                    # Check before requesting the next streaming member: that
                    # request can consume the preceding member's compressed data.
                    if deadline_reached():
                        return stop_preparation()
                    try:
                        member = next(members)
                    except StopIteration:
                        break
                    if not member.isfile() or not member.name.endswith(".h5"):
                        continue
                    name = Path(member.name).name
                    if not name.startswith("file") or name in infos:
                        raise CachePreparationError("Unexpected or duplicate native archive filename")
                    target = directory / name
                    names.append(name)
                    if validate_cache(target, expected_source_bytes=member.size):
                        infos[name] = read_cache_header(target)
                        continue
                    if target.exists() and not _recognized_cache(target):
                        raise CachePreparationError("Existing non-cache HDF5 is preserved: " + name)
                    # Check both filesystems when raw scratch and cache differ.
                    # cache_one_volume also checks the exact cropped-cache size.
                    if native_directory == directory:
                        _reserve(directory, 2 * member.size + 16 * 1024**2, reserve_gb)
                    else:
                        _reserve(native_directory, member.size, reserve_gb)
                        _reserve(directory, member.size + 16 * 1024**2, reserve_gb)
                    fd, native_temp = tempfile.mkstemp(prefix=".ssdm-native-", suffix=".h5.tmp", dir=native_directory)
                    try:
                        digest, written = hashlib.sha256(), 0
                        with os.fdopen(fd, "wb") as output:
                            stream = archive.extractfile(member)
                            if stream is None:
                                raise CachePreparationError("Native archive member could not be read")
                            with stream:
                                while block := stream.read(4 * 1024**2):
                                    output.write(block)
                                    digest.update(block)
                                    written += len(block)
                        if written != member.size:
                            raise CachePreparationError("Incomplete native archive member: " + name)
                        infos[name] = cache_one_volume(
                            native_temp, target, source_archive_member=member.name,
                            source_bytes=member.size, source_sha256=digest.hexdigest(), reserve_gb=reserve_gb,
                        )
                    finally:
                        if os.path.exists(native_temp):
                            os.unlink(native_temp)
                    new_volumes += 1
                    _manifest(directory, names, False, new_volumes, infos)
                    print("Cached", name, "all slices:", infos[name]["slices"],
                          "ready volumes:", len(infos), flush=True)
        if not names:
            raise CachePreparationError("Archive contained no native MRI volumes")
        for name in names:
            if deadline_reached():
                return stop_preparation()
            if not validate_cache(directory / name, expected_source_bytes=infos[name]["source_bytes"]):
                raise CachePreparationError("Final all-slice cache validation failed: " + name)
        if deadline_reached():
            return stop_preparation()
        result = _manifest(directory, names, True, new_volumes, infos)
        print("Full archive cache complete:", len(names), "volumes;", result["total_slices"], "slices", flush=True)
        return result
    except Exception as exc:
        _manifest(directory, names, False, new_volumes, infos)
        if isinstance(exc, CachePreparationError):
            raise
        # Do not reveal URL-bearing transport error strings or exception chains.
        raise CachePreparationError(
            "NYU stream/cache conversion interrupted (" + type(exc).__name__
            + "); completion is false and valid cache volumes can be reused."
        ) from None


def synthetic_cache_selftest():
    """Compare saved slices bit-for-bit with the current raw dataset pipeline."""
    import torch
    from ssdm_experiment import FastMRISlices
    from ssdm_cdl import ri_to_complex

    rng = np.random.RandomState(193)
    kspace = (rng.randn(3, 384, 368) + 1j * rng.randn(3, 384, 368)).astype(np.complex64)
    kspace[2] = 0  # Verify clamp_min normalization also preserves zero slices.
    with tempfile.TemporaryDirectory(prefix="ssdm-cache-selftest-") as folder:
        raw_dir, cache_dir = Path(folder) / "raw", Path(folder) / "cache"
        raw_dir.mkdir()
        cache_dir.mkdir()
        raw, cached = raw_dir / "file_synthetic.h5", cache_dir / "file_synthetic.h5"
        with h5py.File(raw, "w") as f:
            f.create_dataset("kspace", data=kspace)
            f.create_dataset("reconstruction_esc", data=np.zeros((3, 320, 320), dtype=np.float32))
        cache_one_volume(raw, cached, reserve_gb=0)
        assert raw.exists(), "Raw source was modified or deleted"
        assert validate_cache(cached)
        dataset = FastMRISlices(raw_dir, training=True, size=320)
        with h5py.File(cached, "r") as f:
            assert f[CACHE_DATASET].shape == (3, 320, 320)
            errors = []
            for i in range(3):
                expected = ri_to_complex(dataset[i][0]).numpy()
                actual = f[CACHE_DATASET][i]
                assert np.array_equal(actual, expected), "Cache differs from raw preprocessing"
                errors.append(float(np.abs(actual-expected).max()))
        before = hashlib.sha256(raw.read_bytes()).hexdigest()
        try:
            cache_one_volume(raw, raw, reserve_gb=0)
        except CachePreparationError:
            pass
        else:
            raise AssertionError("Raw-file overwrite was not refused")
        assert hashlib.sha256(raw.read_bytes()).hexdigest() == before
        return {"all_slices_preserved": True, "exact_complex64_match": True,
                "max_absolute_errors": errors, "raw_file_preserved": True,
                "native_shape": [3, 384, 368], "cached_shape": [3, 320, 320]}
