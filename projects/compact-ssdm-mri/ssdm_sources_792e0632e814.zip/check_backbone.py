"""Run in the prepared PyTorch runtime; no data or pretrained weights needed."""

import json
import torch

from ssdm_backbone import BackboneConfig, CrossBatchAttention, SSDMUNet


def check_backbone():
    # Verify exact architecture size and a full 320x320 grouped-shape forward
    # without allocating the real ~1.5 GB network on a CPU-only computer.
    with torch.device("meta"):
        model = SSDMUNet(BackboneConfig(use_checkpoint=False)).eval()
        y = model(torch.empty(1, 8, 2, 320, 320), torch.zeros(1, dtype=torch.long))
        assert y.shape == (1, 8, 2, 320, 320)
        report = model.architecture_report()
        assert report["parameters"] == 369_824_514
        assert report["backbone_without_cross_attention_parameters"] == 361_423_618

    # Enable a nonzero attention branch so a no-op cannot pass the isolation test.
    torch.manual_seed(17)
    attn = CrossBatchAttention(64, subspaces=8, heads=4).eval()
    with torch.no_grad():
        attn.proj.weight.copy_(torch.eye(64))
        x = torch.randn(16, 64, 2, 3)
        baseline = attn(x)
        changed = x.clone()
        changed[8:] = torch.randn_like(changed[8:])
        assert torch.allclose(attn(changed)[:8], baseline[:8], atol=1e-6, rtol=1e-5)
        order = torch.tensor([3, 0, 6, 2, 7, 1, 5, 4])
        permuted = x.clone()
        permuted[:8] = x[order]
        assert torch.allclose(attn(permuted)[:8], baseline[order], atol=1e-6, rtol=1e-5)
        assert not torch.allclose(baseline, x)

    x_grad = x.clone().requires_grad_(True)
    attn(x_grad)[0, 0].sum().backward()
    assert x_grad.grad[1:8].abs().sum() > 0, "Components failed to exchange information"
    assert x_grad.grad[8:].abs().sum() == 0, "Different images leaked into attention"
    report["checks"] = {
        "full_resolution_meta_forward": "passed",
        "cross_attention_group_isolation": "passed",
        "component_permutation_equivariance": "passed",
        "within_group_gradient_exchange": "passed",
    }
    return report


if __name__ == "__main__":
    print(json.dumps(check_backbone(), indent=2))
